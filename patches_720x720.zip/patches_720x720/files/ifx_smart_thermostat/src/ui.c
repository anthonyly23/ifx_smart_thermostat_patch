/*
 * SPDX-FileCopyrightText: Copyright The Zephyr Project Contributors
 * SPDX-License-Identifier: Apache-2.0
 *
 * LVGL front panel. See ui.h for the API.
 *
 * LVGL is not thread safe, so every widget call happens on the UI thread.
 * Other threads hand work over through a small message queue.
 */

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/display/cfb.h>
#include <zephyr/drivers/display.h>
#include <zephyr/cache.h>
#include <zephyr/logging/log.h>
#include <zephyr/sys/crc.h>
#include <lvgl.h>
#include <vg_lite.h>
#if defined(__ARM_FEATURE_MVE) && (__ARM_FEATURE_MVE & 1)
#include <arm_mve.h>
#define VIDEO_CONVERT_MVE 1
#endif

#include "decode.h"
#include "rtp.h"
#include "ui.h"
#include "video.h"

LOG_MODULE_REGISTER(doorbell_ui, LOG_LEVEL_INF);

#define UI_STACK_SIZE 8192
#define UI_PRIORITY   6

/* Longest the UI thread will wait when LVGL has nothing pending. It is a
 * ceiling on how stale the clock and the statistics overlay can get, not a
 * frame interval: a picture wakes the thread immediately through the queue.
 */
#define UI_MAX_SLEEP_MS 20U

/* See the comment in ui_thread_fn(). Only for measuring the difference. */
static bool ui_blind_sleep;

void doorbell_ui_set_blind_sleep(bool on)
{
	ui_blind_sleep = on;
}

/* The answer callback tears a call down and sends a DBP message, both of
 * which block. Running it from the LVGL thread meant the screen we had just
 * switched to never got drawn, so hanging up froze the panel on the last
 * video frame until the teardown finished. It gets a thread of its own.
 */
#define ACTION_STACK_SIZE 3072
#define ACTION_PRIORITY	  7

/* Bounds the status text; longer strings are truncated rather than dropped. */
#define UI_STATUS_MAX 48
#define UI_PEER_MAX   48

enum ui_cmd_type {
	UI_CMD_SET_STATUS,
	UI_CMD_SHOW_INCOMING,
	UI_CMD_SHOW_IDLE,
	UI_CMD_ANSWER,
	UI_CMD_DECLINE,
	UI_CMD_SHOW_FRAME,
	UI_CMD_BOOT_STEP,
	UI_CMD_BOOT_DONE,
	UI_CMD_SHOW_STATS,
	UI_CMD_THERMOSTAT,
	UI_CMD_BENCH_SCREEN,
	UI_CMD_LAYOUT_CHECK,
	UI_CMD_ALARM_ALERT,
};

struct ui_cmd {
	enum ui_cmd_type type;
	uint8_t item;
	bool ok;
	char text[UI_STATUS_MAX];
};

K_MSGQ_DEFINE(ui_msgq, sizeof(struct ui_cmd), 8, 4);

/* The screen behind a root from make_screen(); defined with it, below. */
static lv_obj_t *screen_of(lv_obj_t *root);

static K_THREAD_STACK_DEFINE(ui_stack, UI_STACK_SIZE);
static struct k_thread ui_thread;

K_MSGQ_DEFINE(action_msgq, sizeof(enum doorbell_ui_answer), 4, 4);

static K_THREAD_STACK_DEFINE(action_stack, ACTION_STACK_SIZE);
static struct k_thread action_thread;

static doorbell_ui_answer_cb_t answer_cb;

static lv_obj_t *boot_screen;
static lv_obj_t *boot_values[DOORBELL_UI_BOOT_ITEMS];

static lv_obj_t *idle_screen;
static lv_obj_t *idle_status_label;

/* The ring is an overlay on the idle screen rather than a screen of its own:
 * keeping the thermostat visible behind it is what makes a call read as an
 * interruption of something rather than as a change of mode.
 */
static lv_obj_t *incoming_overlay;
static lv_obj_t *incoming_peer_label;
static lv_obj_t *incoming_time_label;

static lv_obj_t *call_screen;
static lv_obj_t *video_image;
static lv_obj_t *call_stats_label;

static lv_obj_t *stats_overlay;
static lv_obj_t *stats_page_label;

/* The smoke-alarm alert lives on the top layer so it shows over whatever
 * screen is up. The border is a transparent-centre frame whose outline is
 * flashed; the warning symbol is its child so it stays steady while the
 * border blinks. alarm_timer does both the flash and the ten-second timeout.
 */
static lv_obj_t *alarm_border;
static lv_timer_t *alarm_timer;
static int64_t alarm_deadline;
static bool alarm_flash_on;

/* The largest picture the panel will show. Anything larger is refused rather
 * than silently cropped, because a quietly wrong picture is harder to notice
 * than a missing one.
 *
 * 416x240 is half the panel in each direction. The cost is two RGB565
 * buffers below, 195 KB each, so raising this further is not free: 640x368
 * would want 460 KB each and GFX_MEMORY does not have it. Going beyond half
 * the panel means sending the picture to the display in its native YUV rather
 * than converting it, which is a later step.
 */
#define VIDEO_MAX_W 480
#define VIDEO_MAX_H 480

/* The GPU wants its source aligned, and a row that starts off a 64 byte
 * boundary is the kind of thing it answers by wedging rather than by
 * complaining.
 *
 * The rows are packed, not padded. LVGL derives the stride from the width
 * itself, so a buffer padded to a wider stride is read back skewed by a few
 * pixels per row, which turns a picture into diagonal noise. Alignment is
 * instead a condition on the width: 160 pixels of RGB565 is 320 bytes, which
 * is a whole number of 64 byte boundaries, so every row lands aligned without
 * padding anything.
 */
#define VIDEO_ALIGNMENT	 64
#define VIDEO_ROW_BYTES(w) ((uint32_t)(w) * sizeof(uint16_t))

/* Two buffers: the decoder writes one while LVGL draws the other. Sharing a
 * single buffer would let a redraw land halfway through a conversion, which
 * shows up as a torn frame roughly once a second and is easy to mistake for a
 * decoder fault.
 *
 * These sit in cacheable memory (.cy_video_buf) and are flushed by hand once a
 * frame, rather than in the uncached .cy_gpu_buf the GPU can read directly.
 * Conversion writes every pixel exactly once, so uncached charged the bus for
 * all of them, while cacheable pays for one flush of the rows just written. The
 * flush is what keeps the GPU's view correct and must not be dropped: the MPU
 * attribute only changes how the CPU sees this memory, and the GPU reads SOCMEM
 * without going through the data cache at all.
 */
static uint16_t video_pixels[2][VIDEO_MAX_W * VIDEO_MAX_H] __aligned(VIDEO_ALIGNMENT)
	Z_GENERIC_SECTION(.cy_video_buf);
static K_MUTEX_DEFINE(video_lock);
static uint8_t video_writing;
static uint8_t video_ready;
static uint16_t video_w;
static uint16_t video_h;
static bool video_refused;
static uint32_t video_shown;
static uint32_t video_rendered;
static uint32_t video_arrived;
static uint32_t video_latency_last;
static uint32_t video_latency_mean;
static uint32_t video_latency_worst;

/*
 * The same measurement carried through to the end of the render.
 *
 * video_latency_* stops when the picture is handed to LVGL and the screen is
 * marked dirty, which is not when anything appears: the scaling blit and the
 * flush to the panel happen in the lv_timer_handler() that follows. Stopping
 * the clock there measured our own scheduling and called it the frame time,
 * which flattered every number in Phase 6 and Phase 8. LV_EVENT_RENDER_READY
 * fires when the display has finished rendering the frame, so it is the last
 * point we can observe without instrumenting the panel driver itself.
 */
static uint32_t render_arrived;
static bool render_pending;
static uint32_t render_latency_last;
static uint32_t render_latency_mean;
static uint32_t render_latency_worst;

static lv_image_dsc_t video_dsc;

/*
 * Whether the picture is handed to the GPU as YUV instead of being coloured in
 * on the CPU first.
 *
 * Turning YUV420 into RGB565 was 13.8 ms of a 38.2 ms frame at 480x480 -- more
 * than the deblocking filter and the intra prediction put together -- and all
 * of it is arithmetic the GPU does for free as part of a blit it already
 * performs to scale the picture onto the panel.
 *
 * The catch is which YUV. This part does not take planar or semi-planar input
 * (gcFEATURE_VG_YUV_INPUT is 0), so NV12 and the decoder's own three-plane
 * layout are both refused. It does take packed YUY2, and YUY2's chroma
 * subsampling is exactly the decoder's: one Cb and one Cr per two horizontal
 * luma samples. So the conversion becomes a repack -- read three planes, write
 * Y0 Cb Y1 Cr -- with no multiplies, no clamping and no colour space at all.
 * Same sixteen bits per pixel as RGB565, so the buffers, stride and alignment
 * are unchanged.
 *
 * Decided once, at init, from the feature bit rather than a build option: if a
 * part ever reports otherwise the CPU conversion is still there and still
 * correct. `doorbell vglite` prints the bit.
 */
static bool video_use_yuy2;

static void post(enum ui_cmd_type type, const char *text)
{
	struct ui_cmd cmd = {.type = type};

	if (text != NULL) {
		strncpy(cmd.text, text, sizeof(cmd.text) - 1);
		cmd.text[sizeof(cmd.text) - 1] = '\0';
	}

	/* Dropping a redraw is preferable to blocking a caller such as the
	 * control thread, so never wait on a full queue.
	 */
	if (k_msgq_put(&ui_msgq, &cmd, K_NO_WAIT) != 0) {
		LOG_WRN("UI queue full, dropping command %d", (int)type);
	}
}

/* The picture is scaled to fill as much of the panel as it can without being
 * distorted or cropped, whatever size it arrives at, so that changing the
 * sender's resolution does not change how big the image looks. Scaling to the
 * width alone overflowed the height the moment the panel became the frame:
 * 320x240 tripled is 960x720 on a 480 pixel high screen. LV_SCALE_NONE is 1:1.
 */
static int32_t video_scale(uint16_t w, uint16_t h)
{
	int32_t box_w = lv_display_get_horizontal_resolution(NULL);
	int32_t box_h = lv_display_get_vertical_resolution(NULL);
	int32_t by_width;
	int32_t by_height;

	if (w == 0 || h == 0) {
		return LV_SCALE_NONE;
	}

	if (CONFIG_DOORBELL_VIDEO_FIT > 0) {
		box_w = MIN(box_w, CONFIG_DOORBELL_VIDEO_FIT);
		box_h = MIN(box_h, CONFIG_DOORBELL_VIDEO_FIT);
	}

	by_width = (int32_t)((uint32_t)box_w * LV_SCALE_NONE / w);
	by_height = (int32_t)((uint32_t)box_h * LV_SCALE_NONE / h);

	return MIN(by_width, by_height);
}

/** Move the most recently converted frame onto the screen. LVGL thread only. */
static void show_frame(void)
{
	if (video_image == NULL) {
		return;
	}

	k_mutex_lock(&video_lock, K_FOREVER);

	video_dsc.header.magic = LV_IMAGE_HEADER_MAGIC;
	video_dsc.header.cf = video_use_yuy2 ? LV_COLOR_FORMAT_YUY2 : LV_COLOR_FORMAT_RGB565;
	video_dsc.header.w = video_w;
	video_dsc.header.h = video_h;
	video_dsc.header.stride = VIDEO_ROW_BYTES(video_w);
	video_dsc.data_size = (uint32_t)video_dsc.header.stride * video_h;
	video_dsc.data = (const uint8_t *)video_pixels[video_ready];

	k_mutex_unlock(&video_lock);

	/* Image caching is off, so each draw reads the buffer as it stands and
	 * no invalidation is needed. Asking for one anyway sends an event to
	 * the GPU draw unit on every frame, which is work at best.
	 */
	lv_image_set_src(video_image, &video_dsc);
	lv_image_set_scale(video_image, video_scale(video_dsc.header.w, video_dsc.header.h));
	lv_obj_invalidate(video_image);

	video_shown++;

	k_mutex_lock(&video_lock, K_FOREVER);
	video_latency_last = k_cyc_to_us_floor32(k_cycle_get_32() - video_arrived);
	if (video_latency_last > video_latency_worst) {
		video_latency_worst = video_latency_last;
	}
	video_latency_mean = video_latency_mean == 0
				     ? video_latency_last
				     : (video_latency_mean * 7 + video_latency_last) / 8;

	/* Hand the arrival stamp to the render-finished handler. If a previous
	 * frame is still pending it is overwritten rather than queued: two
	 * pictures marked dirty inside one refresh produce one render, and the
	 * newer of them is the one that will be on the panel.
	 */
	render_arrived = video_arrived;
	render_pending = true;
	k_mutex_unlock(&video_lock);
}

#if defined(LCD_720_720)
void dc_wait_vblank(void);
void dc_wait_line(uint32_t target);

static void render_start_cb(lv_event_t *e)
{
	lv_area_t video;

	ARG_UNUSED(e);
	if (lv_screen_active() == screen_of(call_screen) && video_image != NULL) {
		lv_obj_get_coords(video_image, &video);
		dc_wait_line((uint32_t)CLAMP(video.y2 + 1, 0, 719));
	} else {
		dc_wait_vblank();
	}
}
#endif

/* Called by LVGL on the UI thread when a rendered frame is complete. */
static void render_ready_cb(lv_event_t *e)
{
	uint32_t now = k_cycle_get_32();
	uint32_t elapsed;

	ARG_UNUSED(e);

	k_mutex_lock(&video_lock, K_FOREVER);

	if (!render_pending) {
		/* A refresh with no new picture in it: the clock, a button
		 * press, the statistics overlay ticking. Not a video frame.
		 */
		k_mutex_unlock(&video_lock);
		return;
	}

	render_pending = false;
	video_rendered++;
	elapsed = k_cyc_to_us_floor32(now - render_arrived);

	render_latency_last = elapsed;
	if (elapsed > render_latency_worst) {
		render_latency_worst = elapsed;
	}
	render_latency_mean = render_latency_mean == 0
				      ? elapsed
				      : (render_latency_mean * 7 + elapsed) / 8;

	k_mutex_unlock(&video_lock);
}

void doorbell_ui_render_latency(uint32_t *last_us, uint32_t *mean_us, uint32_t *worst_us)
{
	k_mutex_lock(&video_lock, K_FOREVER);

	if (last_us != NULL) {
		*last_us = render_latency_last;
	}
	if (mean_us != NULL) {
		*mean_us = render_latency_mean;
	}
	if (worst_us != NULL) {
		*worst_us = render_latency_worst;
	}

	k_mutex_unlock(&video_lock);
}

void doorbell_ui_frame_latency(uint32_t *last_us, uint32_t *mean_us, uint32_t *worst_us)
{
	k_mutex_lock(&video_lock, K_FOREVER);

	if (last_us != NULL) {
		*last_us = video_latency_last;
	}
	if (mean_us != NULL) {
		*mean_us = video_latency_mean;
	}
	if (worst_us != NULL) {
		*worst_us = video_latency_worst;
	}

	k_mutex_unlock(&video_lock);
}

uint32_t doorbell_ui_frames_shown(void)
{
	return video_shown;
}

uint32_t doorbell_ui_frames_rendered(void)
{
	return video_rendered;
}

/** Clamp to a byte, which is what the colour arithmetic can overshoot. */
static inline uint8_t clamp_byte(int32_t value)
{
	if (value < 0) {
		return 0;
	}
	if (value > 255) {
		return 255;
	}

	return (uint8_t)value;
}

/*
 * BT.601, studio-range luma, in integer arithmetic: the decoder's output is
 * full frames and a float conversion here costs more than the decode.
 *
 * The coefficients are the usual 298/409/100/208/516 in Q8 divided by four, so
 * that a whole pixel fits in 16 bit lanes and eight pixels fit in one Helium
 * register. Dividing loses at most half a unit before a shift that throws away
 * three bits anyway, so the pixels are the same ones.
 */
#define YUV_Y	 75
#define YUV_R_CR 102
#define YUV_G_CB 25
#define YUV_G_CR 52
#define YUV_B_CB 129
#define YUV_SHIFT 6
#define YUV_ROUND (1 << (YUV_SHIFT - 1))

static void convert_row_scalar(uint16_t *out_row, const uint8_t *luma_row, const uint8_t *cb_row,
			       const uint8_t *cr_row, uint16_t from, uint16_t width)
{
	for (uint16_t x = from; x < width; x++) {
		int32_t c = (int32_t)luma_row[x] - 16;
		int32_t d = (int32_t)cb_row[x / 2] - 128;
		int32_t e = (int32_t)cr_row[x / 2] - 128;

		uint8_t r = clamp_byte((YUV_Y * c + YUV_R_CR * e + YUV_ROUND) >> YUV_SHIFT);
		uint8_t g = clamp_byte((YUV_Y * c - YUV_G_CB * d - YUV_G_CR * e + YUV_ROUND) >>
				       YUV_SHIFT);
		uint8_t b = clamp_byte((YUV_Y * c + YUV_B_CB * d + YUV_ROUND) >> YUV_SHIFT);

		out_row[x] = (uint16_t)(((r & 0xf8) << 8) | ((g & 0xfc) << 3) | (b >> 3));
	}
}

#ifdef VIDEO_CONVERT_MVE
/** Clamp to a byte and narrow, the last step of every channel. */
static inline uint16x8_t to_byte(int16x8_t v)
{
	v = vshrq_n_s16(v, YUV_SHIFT);
	v = vmaxq_s16(v, vdupq_n_s16(0));
	v = vminq_s16(v, vdupq_n_s16(255));
	return vreinterpretq_u16_s16(v);
}

/** Pack three 0..255 channel vectors into RGB565. */
static inline uint16x8_t pack565(uint16x8_t r, uint16x8_t g, uint16x8_t b)
{
	uint16x8_t rgb = vorrq_u16(vshlq_n_u16(vandq_u16(r, vdupq_n_u16(0xf8)), 8),
				   vshlq_n_u16(vandq_u16(g, vdupq_n_u16(0xfc)), 3));
	return vorrq_u16(rgb, vshrq_n_u16(b, 3));
}

static void convert_row(uint16_t *out_row, const uint8_t *luma_row, const uint8_t *cb_row,
			const uint8_t *cr_row, uint16_t width)
{
	/*
	 * Chroma is half resolution: each pair of luma samples shares one Cb/Cr.
	 * The old loop duplicated chroma with a Helium *gather* (vldrbq_gather),
	 * which profiled as the hot instruction (~4% of the whole core). Instead,
	 * take 16 luma at a time and split them into even/odd pixels with
	 * vmovlbq/vmovltq (the u8->u16 byte de-interleave is free), load the eight
	 * *shared* chroma samples contiguously (no gather), compute each channel's
	 * chroma term once for the pair, and re-interleave the two pixel halves back
	 * out with vst2q. Same pixels as the scalar path (doorbell_ui_convert_selftest
	 * checks this), no gather, 16 px per iteration instead of 8.
	 */
	uint16_t x = 0;

	for (; x + 16 <= width; x += 16) {
		uint8x16_t luma16 = vld1q_u8(luma_row + x);
		/* even pixels L0,L2,..,L14 ; odd pixels L1,L3,..,L15 */
		int16x8_t le = vsubq_n_s16(vreinterpretq_s16_u16(vmovlbq_u8(luma16)), 16);
		int16x8_t lo = vsubq_n_s16(vreinterpretq_s16_u16(vmovltq_u8(luma16)), 16);
		/* eight shared chroma samples, contiguous — no gather */
		int16x8_t d = vsubq_n_s16(
			vreinterpretq_s16_u16(vldrbq_u16(cb_row + x / 2)), 128);
		int16x8_t e = vsubq_n_s16(
			vreinterpretq_s16_u16(vldrbq_u16(cr_row + x / 2)), 128);

		int16x8_t luma_e = vmlaq_n_s16(vdupq_n_s16(YUV_ROUND), le, YUV_Y);
		int16x8_t luma_o = vmlaq_n_s16(vdupq_n_s16(YUV_ROUND), lo, YUV_Y);

		/* the chroma contribution is identical for both pixels of a pair */
		int16x8_t r_cr = vmulq_n_s16(e, YUV_R_CR);
		int16x8_t g_cb = vmulq_n_s16(d, YUV_G_CB);
		int16x8_t g_cr = vmulq_n_s16(e, YUV_G_CR);
		int16x8_t b_cb = vmulq_n_s16(d, YUV_B_CB);

		/* Saturating adds: the blue term can exceed a signed 16 bit lane at
		 * the extremes, where it saturates above 255 — the clamp lands there
		 * anyway.
		 */
		uint16x8_t re = to_byte(vqaddq_s16(luma_e, r_cr));
		uint16x8_t ro = to_byte(vqaddq_s16(luma_o, r_cr));
		uint16x8_t ge = to_byte(vqsubq_s16(vqsubq_s16(luma_e, g_cb), g_cr));
		uint16x8_t go = to_byte(vqsubq_s16(vqsubq_s16(luma_o, g_cb), g_cr));
		uint16x8_t be = to_byte(vqaddq_s16(luma_e, b_cb));
		uint16x8_t bo = to_byte(vqaddq_s16(luma_o, b_cb));

		uint16x8x2_t out2;
		out2.val[0] = pack565(re, ge, be); /* even pixels */
		out2.val[1] = pack565(ro, go, bo); /* odd pixels */
		vst2q_u16(out_row + x, out2);
	}

	convert_row_scalar(out_row, luma_row, cb_row, cr_row, x, width);
}
#else
static void convert_row(uint16_t *out_row, const uint8_t *luma_row, const uint8_t *cb_row,
			const uint8_t *cr_row, uint16_t width)
{
	convert_row_scalar(out_row, luma_row, cb_row, cr_row, 0, width);
}
#endif


/*
 * The vector conversion has to produce exactly the pixels the scalar one
 * would. Nothing downstream would notice if it did not: the end to end test
 * checksums the decoder's luma plane, which is upstream of this, and a colour
 * that is slightly wrong looks like a colour. So check it here, over every
 * luma value against a chroma pair chosen to exercise the saturating add.
 */
uint32_t doorbell_ui_convert_selftest(void)
{
	static uint8_t luma_row[256];
	static uint8_t cb_row[128];
	static uint8_t cr_row[128];
	static uint16_t vector_out[256];
	static uint16_t scalar_out[256];
	uint32_t bad = 0;

	for (uint32_t i = 0; i < sizeof(luma_row); i++) {
		luma_row[i] = (uint8_t)i;
	}

	/* Every luma value against a grid of chroma pairs. Cb and Cr are swept
	 * independently because they enter the three channels with different
	 * coefficients, and the extremes matter: the blue term is the one that
	 * overflows a 16 bit lane and relies on the add saturating to somewhere
	 * the clamp was going to land anyway.
	 */
	for (uint32_t cb = 0; cb < 256; cb += 15) {
		for (uint32_t cr = 0; cr < 256; cr += 15) {
			memset(cb_row, (int)cb, sizeof(cb_row));
			memset(cr_row, (int)cr, sizeof(cr_row));

			convert_row(vector_out, luma_row, cb_row, cr_row, 256);
			convert_row_scalar(scalar_out, luma_row, cb_row, cr_row, 0, 256);

			for (uint32_t i = 0; i < 256; i++) {
				if (vector_out[i] != scalar_out[i]) {
					bad++;
				}
			}
		}
	}

	return bad;
}

/*
 * Repack one row of three-plane YUV420 as packed YUY2, which is what the GPU
 * will take. Two pixels per 32 bit store: the bytes land Y0 Cb Y1 Cr, which on
 * this little-endian core is the low byte first.
 *
 * Vertically the decoder has one chroma row per two luma rows and YUY2 wants
 * one per row, so the caller hands the same chroma row in twice. That is the
 * same upsampling the colour conversion was already doing, and it is what the
 * GPU would have done had it been given 420 directly.
 */
static void pack_row_yuy2_scalar(uint16_t *out_row, const uint8_t *luma_row,
				 const uint8_t *cb_row, const uint8_t *cr_row, uint16_t from,
				 uint16_t width)
{
	uint32_t *out = (uint32_t *)out_row;

	for (uint16_t x = from; x < width; x += 2) {
		uint32_t y0 = luma_row[x];
		uint32_t y1 = luma_row[x + 1U];
		uint32_t u = cb_row[x / 2U];
		uint32_t v = cr_row[x / 2U];

		out[x / 2U] = y0 | (u << 8) | (y1 << 16) | (v << 24);
	}
}

#if defined(__ARM_FEATURE_MVE) && (__ARM_FEATURE_MVE & 1)
/*
 * YUY2 is four interleaved byte streams -- Y even, Cb, Y odd, Cr -- which is
 * precisely what Helium's four-way interleaving store writes. So the whole
 * repack is a de-interleaving load of the luma (splitting even from odd
 * samples, which is the 4:2:2 horizontal pairing) and an interleaving store of
 * it against the two chroma planes read straight through. No arithmetic at
 * all; the pattern is the instruction.
 *
 * Thirty-two pixels a turn: a vector holds sixteen bytes, the luma load takes
 * two of them, and the two chroma planes supply sixteen samples each for
 * exactly those thirty-two luma samples.
 */
static void pack_row_yuy2(uint16_t *out_row, const uint8_t *luma_row, const uint8_t *cb_row,
			  const uint8_t *cr_row, uint16_t width)
{
	uint8_t *out = (uint8_t *)out_row;
	uint16_t x = 0;

	for (; x + 32U <= width; x += 32U) {
		uint8x16x2_t luma = vld2q_u8(luma_row + x);
		uint8x16x4_t yuy2;

		yuy2.val[0] = luma.val[0];
		yuy2.val[1] = vld1q_u8(cb_row + x / 2U);
		yuy2.val[2] = luma.val[1];
		yuy2.val[3] = vld1q_u8(cr_row + x / 2U);

		vst4q_u8(out + (uint32_t)x * 2U, yuy2);
	}

	pack_row_yuy2_scalar(out_row, luma_row, cb_row, cr_row, x, width);
}
#else
static void pack_row_yuy2(uint16_t *out_row, const uint8_t *luma_row, const uint8_t *cb_row,
			  const uint8_t *cr_row, uint16_t width)
{
	pack_row_yuy2_scalar(out_row, luma_row, cb_row, cr_row, 0, width);
}
#endif

/*
 * Force the conversion onto the CPU, or back to the GPU, so the two can be
 * compared on the same board in the same minute. `doorbell blit` times the
 * conversion with no radio in the way, which is the only way to tell these
 * apart: over a call the radio moves the answer further than the change does.
 */
bool doorbell_ui_set_gpu_convert(bool on)
{
	if (on && !vg_lite_query_feature(gcFEATURE_BIT_VG_YUY2_INPUT)) {
		return false;
	}

	k_mutex_lock(&video_lock, K_FOREVER);
	video_use_yuy2 = on;
	k_mutex_unlock(&video_lock);

	return true;
}

bool doorbell_ui_gpu_convert(void)
{
	return video_use_yuy2;
}

/*
 * The vector repack has to lay down exactly the bytes the scalar one would.
 * Nothing downstream would catch it if it did not: the GPU will happily
 * colour in whatever it is handed, and wrong chroma looks like a colour. So
 * check every width the tail can take, against luma and chroma patterns
 * chosen so a swapped Cb/Cr or a swapped even/odd luma cannot pass.
 */
uint32_t doorbell_ui_yuy2_selftest(void)
{
	static uint8_t luma_row[256];
	static uint8_t cb_row[128];
	static uint8_t cr_row[128];
	static uint16_t vector_out[256];
	static uint16_t scalar_out[256];
	uint32_t bad = 0;

	for (uint32_t i = 0; i < sizeof(luma_row); i++) {
		luma_row[i] = (uint8_t)(i * 3U);
	}
	for (uint32_t i = 0; i < sizeof(cb_row); i++) {
		/* Distinct from each other and from the luma, so an
		 * interleave that puts the right byte in the wrong lane shows
		 * up rather than cancelling out.
		 */
		cb_row[i] = (uint8_t)(0x40U + i);
		cr_row[i] = (uint8_t)(0xC0U - i);
	}

	/* Every even width up to the buffer: below one vector, exactly one,
	 * and each remainder the scalar tail has to finish.
	 */
	for (uint16_t w = 2; w <= 256U; w += 2U) {
		memset(vector_out, 0xA5, sizeof(vector_out));
		memset(scalar_out, 0xA5, sizeof(scalar_out));

		pack_row_yuy2(vector_out, luma_row, cb_row, cr_row, w);
		pack_row_yuy2_scalar(scalar_out, luma_row, cb_row, cr_row, 0, w);

		for (uint32_t i = 0; i < sizeof(vector_out) / sizeof(vector_out[0]); i++) {
			if (vector_out[i] != scalar_out[i]) {
				bad++;
			}
		}
	}

	return bad;
}

void doorbell_ui_show_frame(const uint8_t *picture, uint16_t width, uint16_t height,
			    uint16_t visible_w, uint16_t visible_h, uint32_t arrived)
{
	const uint8_t *luma = picture;
	const uint8_t *cb = picture + (uint32_t)width * height;
	const uint8_t *cr = cb + ((uint32_t)width * height) / 4;
	uint16_t *out;
	uint8_t target;

	if (visible_w > VIDEO_MAX_W || visible_h > VIDEO_MAX_H ||
	    (video_use_yuy2 && (visible_w % 2U) != 0U) ||
	    VIDEO_ROW_BYTES(visible_w) % VIDEO_ALIGNMENT != 0) {
		if (!video_refused) {
			video_refused = true;
			LOG_ERR("cannot show %ux%u video: the panel holds %ux%u and needs rows "
				"that are a multiple of %u bytes",
				visible_w, visible_h, VIDEO_MAX_W, VIDEO_MAX_H, VIDEO_ALIGNMENT);
		}
		return;
	}

	k_mutex_lock(&video_lock, K_FOREVER);
	target = video_writing;
	k_mutex_unlock(&video_lock);

	out = video_pixels[target];

	for (uint16_t y = 0; y < visible_h; y++) {
		const uint8_t *luma_row = luma + (uint32_t)y * width;
		const uint8_t *cb_row = cb + (uint32_t)(y / 2) * (width / 2);
		const uint8_t *cr_row = cr + (uint32_t)(y / 2) * (width / 2);
		uint16_t *out_row = out + (uint32_t)y * visible_w;

		if (video_use_yuy2) {
			pack_row_yuy2(out_row, luma_row, cb_row, cr_row, visible_w);
		} else {
			convert_row(out_row, luma_row, cb_row, cr_row, visible_w);
		}
	}

	/*
	 * Push the frame out of the data cache before anything can draw it. The
	 * range is exactly the rows just written, and it is cache-line aligned at
	 * both ends: the buffers are VIDEO_ALIGNMENT aligned and the check above
	 * already requires a row to be a whole number of those, so no partial
	 * line belonging to another variable is written back with it.
	 */
	sys_cache_data_flush_range(out, (size_t)visible_h * VIDEO_ROW_BYTES(visible_w));

	k_mutex_lock(&video_lock, K_FOREVER);
	video_ready = target;
	video_writing = target ^ 1U;
	video_w = visible_w;
	video_h = visible_h;
	video_arrived = arrived;
	k_mutex_unlock(&video_lock);

	post(UI_CMD_SHOW_FRAME, NULL);
}

/*
 * The one place a call is accepted or refused, whether that came from the
 * touch panel or from the shell. Must run on the LVGL thread, because it
 * changes screens.
 */
/* Hand the decision to the action thread. The LVGL thread must return to
 * lv_timer_handler() promptly or nothing it just changed appears on screen.
 */
static void notify_answer(enum doorbell_ui_answer answer)
{
	if (answer_cb == NULL) {
		return;
	}

	if (k_msgq_put(&action_msgq, &answer, K_NO_WAIT) != 0) {
		LOG_WRN("answer queue full, dropping %d", (int)answer);
	}
}

static void action_thread_fn(void *a, void *b, void *c)
{
	ARG_UNUSED(a);
	ARG_UNUSED(b);
	ARG_UNUSED(c);

	for (;;) {
		enum doorbell_ui_answer answer;

		k_msgq_get(&action_msgq, &answer, K_FOREVER);

		if (answer_cb != NULL) {
			answer_cb(answer);
		}
	}
}

static void do_answer(void)
{
	LOG_INF("call answered");

	if (incoming_overlay != NULL) {
		lv_obj_add_flag(incoming_overlay, LV_OBJ_FLAG_HIDDEN);
	}

	lv_scr_load(screen_of(call_screen));

	notify_answer(DOORBELL_UI_ANSWERED);
}

static void do_decline(void)
{
	LOG_INF("call declined");

	if (incoming_overlay != NULL) {
		lv_obj_add_flag(incoming_overlay, LV_OBJ_FLAG_HIDDEN);
	}

	lv_scr_load(screen_of(idle_screen));

	notify_answer(DOORBELL_UI_DECLINED);
}

static void answer_clicked(lv_event_t *e)
{
	ARG_UNUSED(e);

	do_answer();
}

static void hangup_clicked(lv_event_t *e)
{
	ARG_UNUSED(e);

	do_decline();
}


/*
 * The panel. Everything below lays out against these rather than against
 * percentages alone, because a thermostat that is centred but the wrong size
 * reads as a mock-up.
 *
 * These are the size of the glass, which is not the size LVGL thinks the
 * display is. The controller has to pad the framebuffer width so each row
 * starts on a 128 byte boundary, and `struct display_capabilities` has no
 * field for a stride, so the driver carries the padding in the resolution it
 * reports: 800 becomes 832. Laying out against that number puts the right
 * 32 columns off the edge of the panel, which is exactly what D28 was.
 *
 * So ask the panel instead of the controller. Filled in by panel_size_init()
 * before the first screen is built; the defaults below are only what stands
 * until then.
 */
static int32_t panel_w = 800;
static int32_t panel_h = 480;

#define DISPLAY_NODE DT_CHOSEN(zephyr_display)

/*
 * A stacked controller-and-panel binding names the panel it drives, so this
 * is portable to any board wired the same way rather than specific to this
 * one. Where there is no panel phandle the display is the panel, and its own
 * capabilities are the best answer available.
 */
#if DT_NODE_HAS_PROP(DISPLAY_NODE, panel)
#define PANEL_DEV DEVICE_DT_GET(DT_PHANDLE(DISPLAY_NODE, panel))
#else
#define PANEL_DEV DEVICE_DT_GET(DISPLAY_NODE)
#endif

static void panel_size_init(void)
{
	const struct device *panel = PANEL_DEV;
	struct display_capabilities caps;

	if (!device_is_ready(panel)) {
		LOG_WRN("panel not ready, laying out against %dx%d", panel_w, panel_h);
		return;
	}

	display_get_capabilities(panel, &caps);
	if (caps.x_resolution == 0 || caps.y_resolution == 0) {
		LOG_WRN("panel reports no size, laying out against %dx%d", panel_w, panel_h);
		return;
	}

	panel_w = caps.x_resolution;
	panel_h = caps.y_resolution;
	LOG_INF("panel is %dx%d", panel_w, panel_h);
}

/*
 * A screen defaults to the size LVGL thinks the display is, which here is the
 * padded 832 and not the 800 the glass shows. Anything centred or aligned
 * right is then placed against the wrong edge -- centred content lands 16 px
 * right of where it belongs, which is the half of D28 that survives sizing
 * the widgets correctly. Sizing the screen itself puts every alignment back
 * on the glass.
 */
static lv_obj_t *make_screen(void)
{
	lv_obj_t *screen = lv_obj_create(NULL);
	lv_obj_t *root;

	if (screen == NULL) {
		return NULL;
	}

	/* Sizing the screen itself does not hold: LVGL resizes every screen
	 * back to the display whenever the resolution is refreshed, and the
	 * display is the padded 832. So the screen stays whatever LVGL wants
	 * and everything is hung off a root the size of the glass instead.
	 * The 32 columns outside it are never drawn into and are not on the
	 * panel to see.
	 */
	root = lv_obj_create(screen);
	if (root == NULL) {
		return screen;
	}

	lv_obj_remove_style_all(root);
	lv_obj_set_pos(root, 0, 0);
	lv_obj_set_size(root, panel_w, panel_h);
	lv_obj_remove_flag(root, LV_OBJ_FLAG_SCROLLABLE);

	/* Removing every style takes the background opacity with it, so a
	 * colour set on this root by the screen that owns it would not paint
	 * and LVGL's default white would show through from the screen behind.
	 * The root is what the interface treats as its background, so it has
	 * to be opaque; the colour is the caller's business.
	 */
	lv_obj_set_style_bg_opa(root, LV_OPA_COVER, LV_PART_MAIN);

	/* The 32 columns of screen outside the root are not on the glass, but
	 * they are composited during a screen-load fade. Black rather than the
	 * theme's white, so nothing bright is ever mixed in at the edge.
	 */
	lv_obj_set_style_bg_color(screen, lv_color_black(), LV_PART_MAIN);
	lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, LV_PART_MAIN);

	return root;
}

/* The loadable screen behind a root from make_screen(). */
static lv_obj_t *screen_of(lv_obj_t *root)
{
	lv_obj_t *parent = lv_obj_get_parent(root);

	return parent != NULL ? parent : root;
}

/*
 * D28 was invisible to every instrument in this project. A screen laid out 32
 * pixels wider than the glass renders, flushes and times exactly like a
 * correct one -- the same failure shape as D26 and D27, where a display
 * drawing garbage was recorded as a performance win. Only an eye on the panel
 * could tell, and an eye is not a test.
 *
 * So walk the live widget tree and compare it against the size the panel
 * itself reports, not against whatever the layout happens to believe. Asking
 * the panel again here rather than trusting panel_w is the whole point: if
 * the layout constant drifts, the two disagree and this says so.
 */
/*
 * Marks a widget that is deliberately larger than the panel, so the layout
 * check can stay strict about every widget that is not.
 */
#define LAYOUT_OVERSIZE_BY_DESIGN LV_OBJ_FLAG_USER_1

static K_SEM_DEFINE(layout_done, 0, 1);
static int32_t layout_max_x;
static int32_t layout_max_y;
static int32_t layout_panel_w;
static int32_t layout_panel_h;
static uint32_t layout_over;
static const char *layout_screen = "?";
static uint32_t layout_bg_opa;

static void layout_walk(lv_obj_t *obj)
{
	uint32_t n = lv_obj_get_child_count(obj);

	for (uint32_t i = 0; i < n; i++) {
		lv_obj_t *child = lv_obj_get_child(obj, i);
		lv_area_t a;

		/* Parked offscreen on purpose is not a layout fault; only
		 * what is actually shown has to fit.
		 */
		if (lv_obj_has_flag(child, LV_OBJ_FLAG_HIDDEN)) {
			continue;
		}

		lv_obj_get_coords(child, &a);

		if (a.x2 + 1 > layout_max_x) {
			layout_max_x = a.x2 + 1;
		}
		if (a.y2 + 1 > layout_max_y) {
			layout_max_y = a.y2 + 1;
		}
		/* An oversized widget is excused its height, not its width.
		 * The dial hangs off the bottom by design; nothing is allowed
		 * off the right, which is the edge D28 went over.
		 */
		bool tall_by_design = lv_obj_has_flag(child, LAYOUT_OVERSIZE_BY_DESIGN);

		if (a.x2 + 1 > layout_panel_w ||
		    (!tall_by_design && a.y2 + 1 > layout_panel_h)) {
			layout_over++;
			LOG_ERR("widget %u at %d,%d..%d,%d is off a %dx%d panel",
				layout_over, a.x1, a.y1, a.x2, a.y2,
				layout_panel_w, layout_panel_h);
		}

		layout_walk(child);
	}
}

static void layout_check_run(void)
{
	const struct device *panel = PANEL_DEV;
	struct display_capabilities caps;
	lv_obj_t *screen = lv_screen_active();

	layout_max_x = 0;
	layout_max_y = 0;
	layout_over = 0;
	layout_panel_w = panel_w;
	layout_panel_h = panel_h;

	if (device_is_ready(panel)) {
		display_get_capabilities(panel, &caps);
		if (caps.x_resolution != 0 && caps.y_resolution != 0) {
			layout_panel_w = caps.x_resolution;
			layout_panel_h = caps.y_resolution;
		}
	}

	/* Name the screen. The first version of this check reported a clean
	 * 800x480 with nothing over -- of the boot splash, because a separate
	 * bug had left the board stuck on it. A layout check that does not say
	 * what it looked at can pass by looking at the wrong thing.
	 */
	if (screen == screen_of(boot_screen)) {
		layout_screen = "boot";
	} else if (screen == screen_of(idle_screen)) {
		layout_screen = "idle";
	} else if (screen == screen_of(call_screen)) {
		layout_screen = "call";
	} else {
		layout_screen = "unknown";
	}

	/* A background that stopped painting is the same shape of bug as a
	 * layout that runs off the edge: nothing fails, the screen just looks
	 * wrong. Removing every style from the root once took its background
	 * opacity with it and LVGL's default white showed through from behind,
	 * so report what the root would actually paint with.
	 */
	layout_bg_opa = 0;
	if (idle_screen != NULL) {
		layout_bg_opa = lv_obj_get_style_bg_opa(idle_screen, LV_PART_MAIN);
	}

	if (screen != NULL) {
		lv_obj_update_layout(screen);
		layout_walk(screen);
	}

	k_sem_give(&layout_done);
}

/*
 * Fastest rate this unit sustains at its maximum picture size. Measured, not
 * chosen: at 416x240 a ten second call decodes 304 of 304 access units with
 * none dropped and every picture bit-identical to the same bytes decoded on
 * the desktop. Decode is 21.7 ms of the 33.3 ms budget, so there is margin,
 * but not another whole frame of it.
 */
#define PANEL_MAX_FPS 30

void doorbell_ui_video_caps(struct doorbell_ui_video_caps *caps)
{
	if (caps == NULL) {
		return;
	}

	caps->panel_w = panel_w;
	caps->panel_h = panel_h;
	caps->max_w = VIDEO_MAX_W;
	caps->max_h = VIDEO_MAX_H;
	caps->max_fps = PANEL_MAX_FPS;

	/* Expressed in pixels, because that is what the sender chooses. The
	 * check in doorbell_ui_show_frame() is in bytes, so this has to follow
	 * it rather than be written down twice.
	 */
	caps->width_align = VIDEO_ALIGNMENT / sizeof(uint16_t);
}

/*
 * The blue and the red are the logo's own, read out of assets/logo.png rather
 * than matched by eye: 0x005da8 and 0xe20036. The blue is lifted a little here
 * because the logo is meant for white paper and this panel is nearly black.
 *
 * The logo has no green in it, so the green is a secondary-palette one chosen
 * to sit with the other two. It is the controls' colour, which keeps the blue
 * and the red meaning one thing only - cold and hot - rather than also meaning
 * "press me".
 */
#define COLOUR_INK	 0x101820
#define COLOUR_DIM	 0x8899aa
#define COLOUR_TRACK	 0x1c2a36
#define COLOUR_COOL	 0x0f7ad2
#define COLOUR_WARM	 0xe20036
#define COLOUR_IFX_GREEN 0x3cb44b
#define COLOUR_ACCENT	 COLOUR_IFX_GREEN
#define COLOUR_GREEN	 0x2e8b57
#define COLOUR_RED	 0xb22222

/*
 * The readings are invented. There is no thermometer and no humidity sensor on
 * this board, so the temperature is whatever was last written here - by the
 * shell, in practice, which is how the equipment can be driven through heating
 * and cooling without waiting for a room to change. It is kept in one named
 * place with this comment so nobody later mistakes it for something measured.
 *
 * The setpoints and the mode, by contrast, are real state: they are what the
 * user set, and they are the thing the panel and the shell must agree about.
 */
static struct doorbell_ui_thermostat thermostat = {
	.temperature_tenths = 214,
	.humidity = 43,
	.setpoint_min = 20,
	.setpoint_max = 24,
	.mode = DOORBELL_UI_MODE_AUTO,
	.hvac = DOORBELL_UI_HVAC_IDLE,
};

/* Touched by the LVGL thread when a knob is dragged and by whichever thread
 * the shell runs on, so it is not safe to read a field at a time.
 */
static K_MUTEX_DEFINE(thermostat_lock);

static int clock_minutes = 7 * 60 + 42;

/*
 * A third of a degree of hysteresis, so the equipment does not chatter on and
 * off around the setpoint. Without it a reading that sits exactly on the
 * setpoint flickers the running indicator on and off once a second, which
 * looks like a fault and is one on a real system.
 */
#define HVAC_HYSTERESIS_TENTHS 3

/* The dial. A shallow arc across the top of the panel rather than a circle in
 * the middle of it: the panel is 832x480, so a circle big enough to be the
 * subject would leave nothing underneath for the controls. Centred below the
 * bottom edge of the screen, only the top 140 degrees of it are ever visible.
 *
 *   centre (panel_w / 2, 430), radius 400, swept from 200 to 340 degrees
 *   -> spans x 40..792 and y 30..293, leaving y 300..470 for the controls
 */
#define DIAL_CX		(panel_w / 2)
#define DIAL_CY		430
#define DIAL_R		400
#define DIAL_START_DEG	200
#define DIAL_END_DEG	340
#define DIAL_ARC_W	22

static lv_obj_t *idle_temp_label;
static lv_obj_t *idle_unit_label;
static lv_obj_t *idle_clock_label;
static lv_obj_t *idle_humidity_label;
static lv_obj_t *idle_track;
static lv_obj_t *idle_band;
static lv_obj_t *idle_knob_min;
static lv_obj_t *idle_knob_max;
static lv_obj_t *idle_knob_min_label;
static lv_obj_t *idle_knob_max_label;
static lv_obj_t *idle_now_arrow;
static lv_obj_t *idle_hvac_label;
static lv_obj_t *idle_mode_row;
static bool idle_hvac_running;
static lv_point_precise_t idle_arrow_points[4];

/** Where a temperature sits on the dial, in absolute LVGL degrees. */
static int dial_angle(int tenths)
{
	const int lo = DOORBELL_UI_TEMP_MIN * 10;
	const int hi = DOORBELL_UI_TEMP_MAX * 10;

	tenths = CLAMP(tenths, lo, hi);

	return DIAL_START_DEG + (tenths - lo) * (DIAL_END_DEG - DIAL_START_DEG) / (hi - lo);
}

/** The inverse, for turning a touch back into a temperature. */
static int dial_tenths(int degrees)
{
	const int lo = DOORBELL_UI_TEMP_MIN * 10;
	const int hi = DOORBELL_UI_TEMP_MAX * 10;

	degrees = CLAMP(degrees, DIAL_START_DEG, DIAL_END_DEG);

	return lo + (degrees - DIAL_START_DEG) * (hi - lo) /
			    (DIAL_END_DEG - DIAL_START_DEG);
}

/** A point on the dial at the given angle and radius, in screen coordinates. */
static void dial_point(int degrees, int radius, lv_point_t *out)
{
	out->x = DIAL_CX + ((radius * lv_trigo_cos((int16_t)degrees)) >> LV_TRIGO_SHIFT);
	out->y = DIAL_CY + ((radius * lv_trigo_sin((int16_t)degrees)) >> LV_TRIGO_SHIFT);
}

/**
 * The angle of a point relative to the dial's centre, in the same degrees
 * dial_angle() produces.
 *
 * lv_atan2() takes its arguments the other way round from its parameter names:
 * lv_atan2(x, y) is the angle of the vector (y, x), which is 90 - the angle
 * wanted here. Passing dx and dy in the order the names suggest turns a touch
 * at 200 degrees into 250 and one at 284 into 166 - far enough out that most
 * touches fall outside the dial entirely and are thrown away, which is what
 * made the knobs impossible to drag.
 */
static int dial_angle_at(int dx, int dy)
{
	return lv_atan2(dy, dx);
}

/**
 * Check that every position the dial computes lands on the panel.
 *
 * The dial's geometry is five constants and some trigonometry, and every
 * previous defect of this kind in this project was a size that looked right
 * and was not - the LVGL pool, the thread stacks, the VG-Lite heap, the RX
 * buffers, the control column. Rather than pick the numbers and hope, this
 * walks the whole temperature range and counts the knobs, readings and arrow
 * points that would be drawn off the edge.
 *
 * It is cheap enough to run at boot and it reads the real constants, which a
 * test written alongside them on a host would not.
 */
uint32_t doorbell_ui_dial_selftest(void)
{
	uint32_t bad = 0;

	for (int c = DOORBELL_UI_TEMP_MIN; c <= DOORBELL_UI_TEMP_MAX; c++) {
		const int angle = dial_angle(c * 10);
		/* The knob is 40 across and the reading about 30 tall, so each
		 * needs half of that clear of every edge.
		 */
		const struct {
			int radius;
			int half;
		} checks[] = {
			{DIAL_R, 20},
			{DIAL_R - 52, 20},
			{DIAL_R - DIAL_ARC_W / 2 - 4, 2},
			{DIAL_R - DIAL_ARC_W / 2 - 26, 2},
		};

		for (size_t i = 0; i < ARRAY_SIZE(checks); i++) {
			lv_point_t at;

			dial_point(angle, checks[i].radius, &at);

			if (at.x - checks[i].half < 0 || at.x + checks[i].half > panel_w ||
			    at.y - checks[i].half < 0 || at.y + checks[i].half > panel_h) {
				LOG_ERR("dial at %d C radius %d lands at %d,%d, off the panel", c,
					checks[i].radius, (int)at.x, (int)at.y);
				bad++;
			}
		}

		/* And the mapping has to be reversible all the way round: from a
		 * temperature to a point on the ring, and from a touch on that
		 * point back to the same temperature. Checking only
		 * dial_tenths(dial_angle(c)) passes without ever calling
		 * lv_atan2, which is precisely where this was wrong - the
		 * knobs drew in the right place and could not be dragged.
		 */
		lv_point_t on_ring;
		int back;

		dial_point(angle, DIAL_R, &on_ring);
		back = dial_tenths(dial_angle_at(on_ring.x - DIAL_CX, on_ring.y - DIAL_CY));

		if (abs(back - c * 10) > 5) {
			LOG_ERR("%d C draws at %d,%d, and a touch there reads back as %d tenths",
				c, (int)on_ring.x, (int)on_ring.y, back);
			bad++;
		}
	}

	return bad;
}


/** Whether a mode has a heating setpoint, a cooling one, or both. */
static bool mode_has_min(enum doorbell_ui_mode mode)
{
	return mode == DOORBELL_UI_MODE_HEAT || mode == DOORBELL_UI_MODE_AUTO;
}

static bool mode_has_max(enum doorbell_ui_mode mode)
{
	return mode == DOORBELL_UI_MODE_COOL || mode == DOORBELL_UI_MODE_AUTO;
}

const char *doorbell_ui_mode_name(enum doorbell_ui_mode mode)
{
	switch (mode) {
	case DOORBELL_UI_MODE_OFF:
		return "OFF";
	case DOORBELL_UI_MODE_HEAT:
		return "HEAT";
	case DOORBELL_UI_MODE_COOL:
		return "COOL";
	case DOORBELL_UI_MODE_AUTO:
		return "AUTO";
	}

	return "?";
}

const char *doorbell_ui_hvac_name(enum doorbell_ui_hvac hvac)
{
	switch (hvac) {
	case DOORBELL_UI_HVAC_IDLE:
		return "IDLE";
	case DOORBELL_UI_HVAC_HEATING:
		return "HEATING";
	case DOORBELL_UI_HVAC_COOLING:
		return "COOLING";
	}

	return "?";
}

int doorbell_ui_mode_from_name(const char *name, enum doorbell_ui_mode *out)
{
	for (int i = DOORBELL_UI_MODE_OFF; i <= DOORBELL_UI_MODE_AUTO; i++) {
		enum doorbell_ui_mode mode = (enum doorbell_ui_mode)i;

		if (strcasecmp(name, doorbell_ui_mode_name(mode)) == 0) {
			*out = mode;
			return 0;
		}
	}

	return -EINVAL;
}

/**
 * Decide what the equipment should be doing. The caller holds the lock.
 *
 * Hysteresis is applied to the state it is already in, not to the setpoint, so
 * that dragging a knob past the temperature starts the equipment immediately
 * but a reading drifting back across the line does not stop it at once.
 */
static void hvac_recompute(void)
{
	const int t = thermostat.temperature_tenths;
	const int lo = thermostat.setpoint_min * 10;
	const int hi = thermostat.setpoint_max * 10;
	const bool heating = thermostat.hvac == DOORBELL_UI_HVAC_HEATING;
	const bool cooling = thermostat.hvac == DOORBELL_UI_HVAC_COOLING;

	if (mode_has_min(thermostat.mode) &&
	    (heating ? t < lo + HVAC_HYSTERESIS_TENTHS : t < lo)) {
		thermostat.hvac = DOORBELL_UI_HVAC_HEATING;
	} else if (mode_has_max(thermostat.mode) &&
		   (cooling ? t > hi - HVAC_HYSTERESIS_TENTHS : t > hi)) {
		thermostat.hvac = DOORBELL_UI_HVAC_COOLING;
	} else {
		thermostat.hvac = DOORBELL_UI_HVAC_IDLE;
	}
}

static void label_style(lv_obj_t *label, uint32_t colour, const lv_font_t *font)
{
	lv_obj_set_style_text_color(label, lv_color_hex(colour), LV_PART_MAIN);
	lv_obj_set_style_text_font(label, font, LV_PART_MAIN);
}

static lv_obj_t *make_label(lv_obj_t *parent, const char *text, uint32_t colour,
			    const lv_font_t *font)
{
	lv_obj_t *label = lv_label_create(parent);

	lv_label_set_text(label, text);
	label_style(label, colour, font);

	return label;
}

/* Create a rounded action button with a centred label. */
static lv_obj_t *make_action_button(lv_obj_t *parent, const char *text, lv_color_t colour,
				    lv_align_t align, lv_event_cb_t handler)
{
	lv_obj_t *btn = lv_btn_create(parent);
	lv_obj_t *label;

	lv_obj_set_size(btn, 180, 64);
	lv_obj_align(btn, align, align == LV_ALIGN_BOTTOM_LEFT ? 40
			       : align == LV_ALIGN_BOTTOM_RIGHT ? -40 : 0, -28);
	lv_obj_set_style_bg_color(btn, colour, LV_PART_MAIN);
	lv_obj_set_style_radius(btn, 32, LV_PART_MAIN);
	lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
	lv_obj_add_event_cb(btn, handler, LV_EVENT_CLICKED, NULL);

	label = lv_label_create(btn);
	lv_label_set_text(label, text);
	label_style(label, 0xffffff, &lv_font_montserrat_20);
	lv_obj_center(label);

	return btn;
}

/*
 * 1. Boot.
 *
 * White, the logo, and the bring-up steps filling in underneath. The logo is
 * baked into flash as ARGB8888 by scripts/mklogo.py rather than decoded from
 * a PNG at run time: it never changes, and a decoder would cost heap and boot
 * time for no benefit.
 */
extern const lv_image_dsc_t doorbell_logo;

static const char *const boot_titles[DOORBELL_UI_BOOT_ITEMS] = {
	[DOORBELL_UI_BOOT_WIFI] = "Wi-Fi",
	[DOORBELL_UI_BOOT_ADDRESS] = "Address",
	[DOORBELL_UI_BOOT_CONTROL] = "Control",
	[DOORBELL_UI_BOOT_RTSP] = "Stream",
	[DOORBELL_UI_BOOT_AUDIO] = "Audio",
	[DOORBELL_UI_BOOT_DECODER] = "Decoder",
};

static void boot_mark(lv_obj_t *parent)
{
	lv_obj_t *logo = lv_image_create(parent);

	lv_image_set_src(logo, &doorbell_logo);
	lv_obj_align(logo, LV_ALIGN_TOP_MID, 0, 34);
}

static void build_boot_screen(void)
{
	lv_obj_t *name;

	boot_screen = make_screen();
	lv_obj_set_style_bg_color(boot_screen, lv_color_white(), LV_PART_MAIN);
	lv_obj_clear_flag(boot_screen, LV_OBJ_FLAG_SCROLLABLE);

	boot_mark(boot_screen);

	name = make_label(boot_screen, "SMART THERMOSTAT", COLOUR_INK, &lv_font_montserrat_28);
	lv_obj_align(name, LV_ALIGN_TOP_MID, 0, 146);

	for (int i = 0; i < DOORBELL_UI_BOOT_ITEMS; i++) {
		lv_obj_t *title;
		int y = 208 + i * 40;

		title = make_label(boot_screen, boot_titles[i], COLOUR_DIM,
				   &lv_font_montserrat_20);
		lv_obj_align(title, LV_ALIGN_TOP_LEFT, panel_w / 2 - 220, y);

		boot_values[i] = make_label(boot_screen, "...", COLOUR_DIM,
					    &lv_font_montserrat_20);
		lv_obj_align(boot_values[i], LV_ALIGN_TOP_LEFT, panel_w / 2 - 40, y);
	}
}

/*
 * 2. Idle -- a thermostat.
 *
 * This screen is on for essentially the whole life of the device, so it is
 * driven by a one second timer that touches only the labels whose text has
 * changed. Redrawing the composition for a clock tick would be the single
 * most expensive idle behaviour available.
 */
/*
 * Whether the idle screen has fallen behind the model while it was off view.
 *
 * The thermostat keeps running during a call - the temperature changes, the
 * equipment starts and stops - but none of that is on screen, and repainting
 * widgets nobody can see costs the UI thread exactly as much as repainting
 * ones they can. So while the call screen is up the idle screen is left alone
 * and this remembers that it owes a repaint when it comes back.
 */
static bool idle_stale;
static uint32_t idle_repaints;

static void refresh_thermostat(void);

/** True when the idle screen is the one actually on the panel. */
static bool idle_on_view(void)
{
	return (idle_screen != NULL) && (lv_screen_active() == screen_of(idle_screen));
}

static void update_clock(void)
{
	char buf[16];

	if (!idle_on_view()) {
		idle_stale = true;
		return;
	}

	idle_repaints++;

	snprintk(buf, sizeof(buf), "%02d:%02d", (clock_minutes / 60) % 24, clock_minutes % 60);
	lv_label_set_text(idle_clock_label, buf);
}

/*
 * 2b. The running equipment -- flames, snowflakes and a fan.
 *
 * Drawn as paths rather than as a sprite sheet. Flames have to change shape
 * every frame to look like flames at all, snow has to fall past itself, and
 * the fan has to turn through angles a sprite sheet would have to enumerate;
 * all three want gradients. VG-Lite is already the draw unit for this panel
 * and has nothing to do while the idle screen is up, so the tessellation is
 * free in the only sense that matters here - it is not on the CPU.
 *
 * The cost that is not free is the redraw. The artwork is confined to one
 * canvas of 288x104, which is 30k pixels against the panel's 400k, so a frame
 * of it costs about a fourteenth of a full-screen repaint. Animating anything
 * that spanned the dial would cost the lot.
 *
 * 288 is not a round number by accident: at two bytes a pixel a row is 576
 * bytes, which is a whole number of the 64 byte boundaries the GPU wants, so
 * every row lands aligned without padding. The same condition the video path
 * has, for the same reason.
 */
#define ART_PERIOD_MS 50

static lv_obj_t *idle_art;
static lv_timer_t *art_timer;
static uint32_t art_phase;
static uint32_t art_frames;
static uint32_t art_paths;

/*
 * Whether the artwork draws at all.
 *
 * "The UI thread takes N microseconds" is not a measurement of anything
 * without the same number with the animation stopped, and the only honest way
 * to get that is to be able to stop it on the running board.
 */
#if defined(LCD_720_720)
/* Off on the single-buffered panel, where a full-height animation tears; the shell can turn it on. */
static bool art_wanted;
#else
static bool art_wanted = true;
#endif

/*
 * What lv_timer_handler() costs.
 *
 * The background artwork is recomposed inside it, so this is where the price
 * of animating the whole screen shows up. Measuring it here rather than
 * timing art_render() is deliberate: the vector work is handed to the draw
 * unit and finished later, so timing the call that queues it would have
 * measured almost nothing and called the animation free.
 */
static uint32_t ui_handler_worst_us;
static uint64_t ui_handler_total_us;
static uint32_t ui_handler_calls;

static enum doorbell_ui_hvac art_state = DOORBELL_UI_HVAC_IDLE;

/*
 * Where the fan sits: centred, just below the inner edge of the dial.
 *
 * The arc is swept about (DIAL_CX, DIAL_CY) at DIAL_R, so at its apex the
 * inner edge is at DIAL_CY - DIAL_R + DIAL_ARC_W / 2, which is y = 41. A fan
 * of radius 28 centred at y = 88 spans 60 to 116, clear of the arc above it
 * and of the temperature reading below it, which starts at y = 120.
 */
#define FAN_CX 416.0f
#define FAN_CY 88.0f
#define FAN_R  28.0f

/*
 * How strongly the background reads.
 *
 * The artwork is behind the whole interface, not beside it, so it has to lose
 * every contest with the text on top of it. At full strength a flame behind
 * the mode buttons makes them unreadable; at this opacity it is scenery.
 */
#define ART_BACK_OPA LV_OPA_40
#define ART_FAN_OPA  LV_OPA_70

/* The veins have to be visible against a blade that is itself faint, so they
 * are brighter than the artwork they sit on rather than dimmer.
 */
#define ART_VEIN_OPA LV_OPA_60
#define LEAF_VEINS   4
#define ART_LEAVES   5

static void art_set_gradient(lv_draw_vector_dsc_t *dsc, uint32_t from, uint32_t to, float x1,
			     float y1, float x2, float y2)
{
	lv_grad_stop_t stops[2] = {
		{.color = lv_color_hex(from), .opa = LV_OPA_COVER, .frac = 0},
		{.color = lv_color_hex(to), .opa = LV_OPA_COVER, .frac = 255},
	};

	lv_draw_vector_dsc_set_fill_gradient_color_stops(dsc, stops, 2);
	lv_draw_vector_dsc_set_fill_linear_gradient(dsc, x1, y1, x2, y2);
	lv_draw_vector_dsc_set_fill_gradient_spread(dsc, LV_VECTOR_GRADIENT_SPREAD_PAD);
}

/*
 * One flame: a teardrop, wide at the base and drawn to a point at the tip.
 *
 * The dance is in the two control points at the sides. Swinging them in
 * opposite directions leans the flame one way and then the other without
 * moving its base, which is what a flame does; moving the tip instead makes it
 * look like a flag.
 */
static void art_flame(lv_draw_vector_dsc_t *dsc, float cx, float base, float w, float h,
		      float lean)
{
	lv_vector_path_t *path = lv_vector_path_create(LV_VECTOR_PATH_QUALITY_MEDIUM);
	lv_fpoint_t p0 = {cx - w, base};
	lv_fpoint_t tip = {cx + lean * 0.5f, base - h};

	lv_vector_path_move_to(path, &p0);

	/* Up the left side, bulging outwards and leaning with the draught. */
	lv_fpoint_t c1 = {cx - w * 1.5f + lean, base - h * 0.45f};
	lv_fpoint_t c2 = {cx - w * 0.5f + lean, base - h * 0.8f};

	lv_vector_path_cubic_to(path, &c1, &c2, &tip);

	/* And down the right, mirrored, so the two sides meet at the tip. */
	lv_fpoint_t c3 = {cx + w * 0.5f + lean, base - h * 0.8f};
	lv_fpoint_t c4 = {cx + w * 1.5f + lean, base - h * 0.45f};
	lv_fpoint_t p1 = {cx + w, base};

	lv_vector_path_cubic_to(path, &c3, &c4, &p1);
	lv_vector_path_close(path);

	lv_draw_vector_dsc_add_path(dsc, path);
	lv_vector_path_delete(path);
}

/** A six-armed snowflake, as six spokes with a tick on each. */
static void art_snowflake(lv_draw_vector_dsc_t *dsc, float cx, float cy, float r)
{
	lv_vector_path_t *path = lv_vector_path_create(LV_VECTOR_PATH_QUALITY_MEDIUM);
	const float arm = r * 0.22f;

	for (int i = 0; i < 6; i++) {
		const float a = (float)i * 60.0f * 3.14159265f / 180.0f;
		const float ca = cosf(a);
		const float sa = sinf(a);
		/* A spoke, as a thin quadrilateral: the vector API fills
		 * shapes, and a zero-width line has nothing to fill.
		 */
		lv_fpoint_t p[4] = {
			{cx - sa * arm * 0.35f, cy + ca * arm * 0.35f},
			{cx + ca * r - sa * arm * 0.18f, cy + sa * r + ca * arm * 0.18f},
			{cx + ca * r + sa * arm * 0.18f, cy + sa * r - ca * arm * 0.18f},
			{cx + sa * arm * 0.35f, cy - ca * arm * 0.35f},
		};

		lv_vector_path_move_to(path, &p[0]);
		lv_vector_path_line_to(path, &p[1]);
		lv_vector_path_line_to(path, &p[2]);
		lv_vector_path_line_to(path, &p[3]);
		lv_vector_path_close(path);

		/* The barbs, two thirds of the way out. */
		for (int side = -1; side <= 1; side += 2) {
			const float bx = cx + ca * r * 0.62f;
			const float by = cy + sa * r * 0.62f;
			const float b = a + (float)side * 0.9f;
			lv_fpoint_t q[3] = {
				{bx, by},
				{bx + cosf(b) * arm, by + sinf(b) * arm},
				{bx + ca * arm * 0.3f, by + sa * arm * 0.3f},
			};

			lv_vector_path_move_to(path, &q[0]);
			lv_vector_path_line_to(path, &q[1]);
			lv_vector_path_line_to(path, &q[2]);
			lv_vector_path_close(path);
		}
	}

	lv_draw_vector_dsc_add_path(dsc, path);
	lv_vector_path_delete(path);
}

/** The fan: three blades about a hub, turned to the given angle. */
static void art_fan(lv_draw_vector_dsc_t *dsc, float degrees)
{
	lv_vector_path_t *path = lv_vector_path_create(LV_VECTOR_PATH_QUALITY_MEDIUM);
	lv_fpoint_t hub = {0.0f, 0.0f};
	lv_matrix_t m;

	/* Drawn about the origin and moved into place by the transform, so the
	 * rotation is a property of the matrix rather than something every
	 * point has to have applied to it by hand.
	 */
	lv_matrix_identity(&m);
	lv_matrix_translate(&m, FAN_CX, FAN_CY);
	lv_matrix_rotate(&m, degrees);
	lv_draw_vector_dsc_set_transform(dsc, &m);

	for (int i = 0; i < 3; i++) {
		const float a = (float)i * 120.0f * 3.14159265f / 180.0f;
		const float ca = cosf(a);
		const float sa = sinf(a);
		/* A blade: out from the hub, swept back at the tip so it reads
		 * as turning in one particular direction.
		 */
		lv_fpoint_t root = {ca * FAN_R * 0.18f, sa * FAN_R * 0.18f};
		lv_fpoint_t c1 = {ca * FAN_R * 0.7f - sa * FAN_R * 0.42f,
				  sa * FAN_R * 0.7f + ca * FAN_R * 0.42f};
		lv_fpoint_t tip = {ca * FAN_R, sa * FAN_R};
		lv_fpoint_t c2 = {ca * FAN_R * 0.75f + sa * FAN_R * 0.12f,
				  sa * FAN_R * 0.75f - ca * FAN_R * 0.12f};

		lv_vector_path_move_to(path, &root);
		lv_vector_path_quad_to(path, &c1, &tip);
		lv_vector_path_quad_to(path, &c2, &root);
		lv_vector_path_close(path);
	}

	lv_vector_path_append_circle(path, &hub, FAN_R * 0.2f, FAN_R * 0.2f);

	lv_draw_vector_dsc_add_path(dsc, path);
	lv_vector_path_delete(path);

	lv_matrix_identity(&m);
	lv_draw_vector_dsc_set_transform(dsc, &m);
}

/*
 * Where the edge of the blade is, a fraction of the way along it.
 *
 * The blade is a quadratic from the stem through a control point out at the
 * side to the tip, so the margin is that curve evaluated at t. The veins have
 * to end *on* it: a vein that stops short looks like a crack, and one that
 * runs past it looks like a tear.
 */
static lv_fpoint_t leaf_margin(float len, float w, float side, float t)
{
	const float u = 1.0f - t;
	lv_fpoint_t p = {
		2.0f * u * t * (side * w),
		-(2.0f * u * t * (len * 0.45f) + t * t * len),
	};

	return p;
}

/*
 * One vein, as a filled sliver that tapers from the midrib to the margin.
 *
 * Filled rather than stroked, which is not a stylistic choice: a path carrying
 * a stroke but no fill wedges the VG-Lite backend. Bisected on the board - the
 * blade with a stroked outline is fine, a stroke-only path asserts inside the
 * gradient cache within a second. The snowflake's arms are filled slivers for
 * the same reason, and have never once misbehaved.
 *
 * Tapering is what makes it read as a vein. A constant-width sliver looks like
 * a wire laid on the leaf.
 */
static void leaf_vein(lv_vector_path_t *path, lv_fpoint_t a, lv_fpoint_t b, float wa, float wb)
{
	const float dx = b.x - a.x;
	const float dy = b.y - a.y;
	const float len = sqrtf(dx * dx + dy * dy);
	float nx;
	float ny;
	lv_fpoint_t q[4];

	if (len < 0.001f) {
		return;
	}

	/* The unit normal, which is the direction the sliver has width in. */
	nx = -dy / len;
	ny = dx / len;

	q[0].x = a.x + nx * wa;
	q[0].y = a.y + ny * wa;
	q[1].x = b.x + nx * wb;
	q[1].y = b.y + ny * wb;
	q[2].x = b.x - nx * wb;
	q[2].y = b.y - ny * wb;
	q[3].x = a.x - nx * wa;
	q[3].y = a.y - ny * wa;

	lv_vector_path_move_to(path, &q[0]);
	lv_vector_path_line_to(path, &q[1]);
	lv_vector_path_line_to(path, &q[2]);
	lv_vector_path_line_to(path, &q[3]);
	lv_vector_path_close(path);
}

/* Where a leaf is and how far over it is leaning, worked out once so the blade
 * and the veins drawn in the second pass agree about it.
 */
struct leaf_place {
	float x;
	float y;
	float len;
	float w;
	float sway;
};

static struct leaf_place leaf_at(int i, uint32_t phase)
{
	const float t = (float)(phase + (uint32_t)i * 37) * 0.035f;
	struct leaf_place leaf;

	leaf.len = 130.0f + (float)((i * 7) % 3) * 22.0f;
	leaf.w = leaf.len * 0.34f;
	leaf.x = 96.0f + (float)i * 160.0f;
	leaf.y = (float)panel_h + 8.0f;
	leaf.sway = sinf(t) * 7.0f + (float)(i - 2) * 9.0f;

	return leaf;
}

/** Put the leaf's own transform on the descriptor: it sways about its stem. */
static void leaf_transform(lv_draw_vector_dsc_t *dsc, const struct leaf_place *leaf)
{
	lv_matrix_t m;

	lv_matrix_identity(&m);
	lv_matrix_translate(&m, leaf->x, leaf->y);
	lv_matrix_rotate(&m, leaf->sway);
	lv_draw_vector_dsc_set_transform(dsc, &m);
}

/*
 * The blade: two curves from the stem to the tip.
 *
 * Drawn about its own stem at the origin so the sway can be a rotation. A leaf
 * on a stalk pivots where it is attached; rotating it about its middle makes
 * it look like it has come off.
 */
static void art_leaf_blade(lv_draw_vector_dsc_t *dsc, const struct leaf_place *leaf)
{
	lv_vector_path_t *blade = lv_vector_path_create(LV_VECTOR_PATH_QUALITY_MEDIUM);
	lv_fpoint_t stem = {0.0f, 0.0f};
	lv_fpoint_t tip = {0.0f, -leaf->len};
	lv_fpoint_t left = {-leaf->w, -leaf->len * 0.45f};
	lv_fpoint_t right = {leaf->w, -leaf->len * 0.45f};

	leaf_transform(dsc, leaf);

	lv_vector_path_move_to(blade, &stem);
	lv_vector_path_quad_to(blade, &left, &tip);
	lv_vector_path_quad_to(blade, &right, &stem);
	lv_vector_path_close(blade);

	lv_draw_vector_dsc_add_path(dsc, blade);
	lv_vector_path_delete(blade);
}

/** The midrib and the veins branching off it to the margin. */
static void art_leaf_veins(lv_draw_vector_dsc_t *dsc, const struct leaf_place *leaf)
{
	lv_vector_path_t *veins = lv_vector_path_create(LV_VECTOR_PATH_QUALITY_MEDIUM);
	lv_fpoint_t stem = {0.0f, 0.0f};
	lv_fpoint_t tip = {0.0f, -leaf->len};

	leaf_transform(dsc, leaf);

	leaf_vein(veins, stem, tip, 1.7f, 0.4f);

	for (int i = 0; i < LEAF_VEINS; i++) {
		/* Evenly along the blade, but stopping short of the tip: the
		 * last stretch is too narrow for a vein to be anything but a
		 * smudge across the midrib.
		 */
		const float t = 0.22f + (float)i * (0.52f / (float)(LEAF_VEINS - 1));

		for (float side = -1.0f; side < 2.0f; side += 2.0f) {
			const lv_fpoint_t edge = leaf_margin(leaf->len, leaf->w, side, t);
			/* The vein leaves the midrib below where it meets the
			 * margin, so it sweeps forward towards the tip. Veins
			 * at right angles to the rib look like a ladder.
			 */
			lv_fpoint_t root = {0.0f, edge.y + leaf->len * 0.13f};

			leaf_vein(veins, root, edge, 1.2f, 0.35f);
		}
	}

	lv_draw_vector_dsc_add_path(dsc, veins);
	lv_vector_path_delete(veins);
}

/**
 * What the artwork drew last time round.
 *
 * Nobody can see this panel from a script, and the artwork no longer has a
 * buffer of its own to checksum - it goes straight onto the screen. What can
 * still be checked without eyes is that a frame was composed, that it was
 * composed of the number of shapes that state calls for, and that the drawing
 * is not making the UI thread late.
 */
void doorbell_ui_art_stats(struct doorbell_ui_art_stats *out)
{
	out->state = (uint32_t)art_state;
	out->paths = art_paths;
	out->steps = art_phase;
	out->composes = art_frames;
	out->repaints = idle_repaints;
	out->handler_worst_us = ui_handler_worst_us;
	out->handler_mean_us = (ui_handler_calls == 0)
				       ? 0
				       : (uint32_t)(ui_handler_total_us / ui_handler_calls);
}

/** Forget the timings, so a measurement can be about one thing. */
void doorbell_ui_art_reset(void)
{
	ui_handler_worst_us = 0;
	ui_handler_total_us = 0;
	ui_handler_calls = 0;
	art_frames = 0;
	idle_repaints = 0;
}

/**
 * Compose the background for the given equipment state.
 *
 * Straight onto the layer the screen is being drawn into: no canvas, no buffer
 * and no clear. The screen's own background colour is already there, which is
 * both a quarter of a megabyte saved and the end of the colour mismatch a
 * canvas cleared to its own idea of the background had.
 */
static void art_render(lv_layer_t *layer, enum doorbell_ui_hvac hvac, uint32_t phase)
{
	lv_draw_vector_dsc_t *dsc = lv_draw_vector_dsc_create(layer);
	lv_matrix_t reset;
	uint32_t paths = 0;

	lv_draw_vector_dsc_set_fill_opa(dsc, ART_BACK_OPA);

	if (hvac == DOORBELL_UI_HVAC_HEATING) {
		/* Deep red at the base, yellow at the tips: a flame is hottest
		 * where it is thinnest, and this is the one colour cue that
		 * makes a teardrop read as fire rather than as a leaf.
		 */
		art_set_gradient(dsc, 0xffd83a, 0xc41200, 0.0f, (float)panel_h - 190.0f, 0.0f,
				 (float)panel_h);

		for (int i = 0; i < 7; i++) {
			/* Each flame gets its own phase, so they do not all
			 * lean the same way at the same moment - which is what
			 * makes seven flames look like a fire and not like a
			 * comb.
			 */
			const float t = (float)(phase + (uint32_t)i * 23) * 0.13f;
			const float lean = sinf(t) * 11.0f;
			const float h = 120.0f + sinf(t * 1.7f) * 26.0f;
			const float x = 60.0f + (float)i * 118.0f;

			art_flame(dsc, x, (float)panel_h + 6.0f, 34.0f, h, lean);
			paths++;
		}
	} else if (hvac == DOORBELL_UI_HVAC_COOLING) {
		art_set_gradient(dsc, 0xffffff, 0x2f9be0, 0.0f, 0.0f, 0.0f, (float)panel_h);

		for (int i = 0; i < 9; i++) {
			/* They fall at different speeds and wrap round the top,
			 * which is cheaper than keeping a list of flakes and
			 * looks the same.
			 */
			const uint32_t speed = 2 + (uint32_t)i % 3;
			const float y =
				(float)((phase * speed + (uint32_t)i * 97) % (panel_h + 80)) - 40.0f;
			const float x = 46.0f + (float)i * 92.0f;

			art_snowflake(dsc, x, y, 30.0f - (float)(i % 3) * 7.0f);
			paths++;
		}
	} else {
		/*
		 * Nothing is running, so nothing is being spent: one slow row
		 * of leaves, swaying out of step with each other.
		 *
		 * Two passes, all the blades and then all the veins, so the
		 * fill is set twice per frame rather than twice per leaf. The
		 * descriptor's fill is a mode the next path inherits, and
		 * flipping it back and forth inside the loop is how the first
		 * attempt at this ended up drawing four of the five leaves in
		 * the vein colour.
		 */
		art_set_gradient(dsc, 0x7fd66a, 0x1f7a3c, 0.0f, (float)panel_h - 170.0f, 0.0f,
				 (float)panel_h);

		for (int i = 0; i < ART_LEAVES; i++) {
			const struct leaf_place leaf = leaf_at(i, phase);

			art_leaf_blade(dsc, &leaf);
			paths++;
		}

		lv_draw_vector_dsc_set_fill_color(dsc, lv_color_hex(0xd8f5c8));
		lv_draw_vector_dsc_set_fill_opa(dsc, ART_VEIN_OPA);

		for (int i = 0; i < ART_LEAVES; i++) {
			const struct leaf_place leaf = leaf_at(i, phase);

			art_leaf_veins(dsc, &leaf);
			paths++;
		}

		lv_draw_vector_dsc_set_fill_opa(dsc, ART_BACK_OPA);
		lv_matrix_identity(&reset);
		lv_draw_vector_dsc_set_transform(dsc, &reset);
	}

	/* The fan turns whenever the equipment is running, whichever way round
	 * it is: the air handler is the same machine in both cases. When
	 * nothing is running there is no fan, because there is no fan.
	 */
	if (hvac != DOORBELL_UI_HVAC_IDLE) {
		art_set_gradient(dsc, 0xe8eef5, 0x7d8ea0, FAN_CX - FAN_R, FAN_CY - FAN_R,
				 FAN_CX + FAN_R, FAN_CY + FAN_R);
		lv_draw_vector_dsc_set_fill_opa(dsc, ART_FAN_OPA);
		art_fan(dsc, (float)(phase * 9 % 360));
		paths++;
	}

	lv_draw_vector(dsc);
	lv_draw_vector_dsc_delete(dsc);

	art_paths = paths;
	art_frames++;
}

/** Draw the background, every time the screen behind the interface is painted. */
static void art_draw_cb(lv_event_t *e)
{
	if (!art_wanted) {
		return;
	}

	art_render(lv_event_get_layer(e), art_state, art_phase);
}

/*
 * The clock the artwork runs on.
 *
 * A timer rather than an lv_anim, because what changes is not one property
 * being interpolated but a whole picture being recomposed. It runs only while
 * the idle screen is the screen on show: during a call this panel has a video
 * decoder to feed and must not be spending anything on scenery.
 */
static void art_tick(lv_timer_t *timer)
{
	ARG_UNUSED(timer);

	art_phase++;
	lv_obj_invalidate(idle_art);
}

static void art_run(bool on)
{
	if (on && (art_timer == NULL)) {
		art_timer = lv_timer_create(art_tick, ART_PERIOD_MS, NULL);
	} else if (!on && (art_timer != NULL)) {
		lv_timer_delete(art_timer);
		art_timer = NULL;
	}
}

/*
 * Turn the animation off, so its cost can be measured by difference.
 *
 * "The UI thread takes N microseconds" is not a measurement of anything
 * without the same number with the animation stopped, and the only honest way
 * to get that is to be able to stop it on the running board.
 */
void doorbell_ui_art_enable(bool on)
{
	art_wanted = on;
	art_run(on);
	if (idle_art != NULL) {
		lv_obj_invalidate(idle_art);
	}
}

static void art_screen_loaded(lv_event_t *e)
{
	ARG_UNUSED(e);

	art_run(art_wanted);

	/* Pay back everything that was skipped while the call screen was up,
	 * in one repaint rather than the several that were deferred.
	 */
	if (idle_stale) {
		idle_stale = false;
		update_clock();
		refresh_thermostat();
	}
}

static void art_screen_unloaded(lv_event_t *e)
{
	ARG_UNUSED(e);
	art_run(false);
}

/* Which picture the background draws. The drawing itself happens in the
 * screen's own draw callback, so all this has to do is say what to draw.
 */
static void set_hvac_animation(enum doorbell_ui_hvac hvac)
{
	if (hvac == art_state) {
		return;
	}

	art_state = hvac;
	idle_hvac_running = (hvac != DOORBELL_UI_HVAC_IDLE);
	lv_obj_invalidate(idle_art);
}

/** Put a knob and its reading on the dial at the given temperature. */
static void place_knob(lv_obj_t *knob, lv_obj_t *label, int celsius, bool shown)
{
	lv_point_t at;
	char buf[8];

	if (!shown) {
		lv_obj_add_flag(knob, LV_OBJ_FLAG_HIDDEN);
		lv_obj_add_flag(label, LV_OBJ_FLAG_HIDDEN);
		return;
	}

	lv_obj_remove_flag(knob, LV_OBJ_FLAG_HIDDEN);
	lv_obj_remove_flag(label, LV_OBJ_FLAG_HIDDEN);

	dial_point(dial_angle(celsius * 10), DIAL_R, &at);
	lv_obj_set_pos(knob, at.x - lv_obj_get_width(knob) / 2,
		       at.y - lv_obj_get_height(knob) / 2);

	/* The reading sits inside the ring, where there is always room. Outside
	 * it there is not: the top of the dial is 30 pixels from the edge of
	 * the panel.
	 */
	dial_point(dial_angle(celsius * 10), DIAL_R - 52, &at);
	snprintk(buf, sizeof(buf), "%d" LV_SYMBOL_UP, celsius);
	lv_label_set_text(label, buf);
	lv_obj_update_layout(label);
	lv_obj_set_pos(label, at.x - lv_obj_get_width(label) / 2,
		       at.y - lv_obj_get_height(label) / 2);
}

/** Point the current-temperature arrow at where the reading falls on the dial. */
static void place_arrow(int tenths)
{
	const int angle = dial_angle(tenths);
	lv_point_t tip;
	lv_point_t left;
	lv_point_t right;

	/* A triangle, computed rather than drawn: it has to point along the
	 * radius, and the radius points somewhere different at every
	 * temperature. LVGL will rotate an image but not a glyph, and a
	 * three-point polyline is cheaper than either.
	 */
	dial_point(angle, DIAL_R - DIAL_ARC_W / 2 - 4, &tip);
	dial_point(angle - 3, DIAL_R - DIAL_ARC_W / 2 - 26, &left);
	dial_point(angle + 3, DIAL_R - DIAL_ARC_W / 2 - 26, &right);

	idle_arrow_points[0].x = tip.x;
	idle_arrow_points[0].y = tip.y;
	idle_arrow_points[1].x = left.x;
	idle_arrow_points[1].y = left.y;
	idle_arrow_points[2].x = right.x;
	idle_arrow_points[2].y = right.y;
	idle_arrow_points[3] = idle_arrow_points[0];

	lv_line_set_points(idle_now_arrow, idle_arrow_points, 4);
}

/** Repaint everything the thermostat state drives. LVGL thread only. */
static void refresh_thermostat(void)
{
	if (!idle_on_view()) {
		idle_stale = true;
		return;
	}

	struct doorbell_ui_thermostat now;
	uint32_t band_colour;
	char buf[24];

	if (idle_track == NULL) {
		return;
	}

	k_mutex_lock(&thermostat_lock, K_FOREVER);
	now = thermostat;
	k_mutex_unlock(&thermostat_lock);

	snprintk(buf, sizeof(buf), "%d.%d", now.temperature_tenths / 10,
		 abs(now.temperature_tenths % 10));
	lv_label_set_text(idle_temp_label, buf);
	lv_obj_update_layout(idle_temp_label);
	lv_obj_align(idle_temp_label, LV_ALIGN_TOP_MID, -18, 120);
	lv_obj_align_to(idle_unit_label, idle_temp_label, LV_ALIGN_OUT_RIGHT_TOP, 4, 8);

	snprintk(buf, sizeof(buf), LV_SYMBOL_TINT " %d%%", now.humidity);
	lv_label_set_text(idle_humidity_label, buf);

	place_arrow(now.temperature_tenths);
	place_knob(idle_knob_min, idle_knob_min_label, now.setpoint_min, mode_has_min(now.mode));
	place_knob(idle_knob_max, idle_knob_max_label, now.setpoint_max, mode_has_max(now.mode));

	/* The band spans what the thermostat is holding: between the two
	 * setpoints in auto, and from the single setpoint out to the end of the
	 * dial otherwise - which is what "heat to at least this" means.
	 */
	if (now.mode == DOORBELL_UI_MODE_OFF) {
		lv_obj_add_flag(idle_band, LV_OBJ_FLAG_HIDDEN);
	} else {
		int from = mode_has_min(now.mode) ? dial_angle(now.setpoint_min * 10)
						 : DIAL_START_DEG;
		int to = mode_has_max(now.mode) ? dial_angle(now.setpoint_max * 10)
						: DIAL_END_DEG;

		lv_obj_remove_flag(idle_band, LV_OBJ_FLAG_HIDDEN);
		lv_arc_set_angles(idle_band, from, to);

		band_colour = COLOUR_IFX_GREEN;
		if (now.mode == DOORBELL_UI_MODE_HEAT) {
			band_colour = COLOUR_WARM;
		} else if (now.mode == DOORBELL_UI_MODE_COOL) {
			band_colour = COLOUR_COOL;
		}

		lv_obj_set_style_arc_color(idle_band, lv_color_hex(band_colour),
					   LV_PART_INDICATOR);
	}

	if (now.hvac == DOORBELL_UI_HVAC_IDLE) {
		lv_label_set_text(idle_hvac_label,
				  now.mode == DOORBELL_UI_MODE_OFF ? "off" : "idle");
		lv_obj_set_style_text_color(idle_hvac_label, lv_color_hex(COLOUR_DIM),
					    LV_PART_MAIN);
		set_hvac_animation(DOORBELL_UI_HVAC_IDLE);
	} else {
		const bool heating = now.hvac == DOORBELL_UI_HVAC_HEATING;

		snprintk(buf, sizeof(buf), "%s %s", heating ? LV_SYMBOL_CHARGE : LV_SYMBOL_TINT,
			 doorbell_ui_hvac_name(now.hvac));
		lv_label_set_text(idle_hvac_label, buf);
		lv_obj_set_style_text_color(idle_hvac_label,
					    lv_color_hex(heating ? COLOUR_WARM : COLOUR_COOL),
					    LV_PART_MAIN);
		set_hvac_animation(now.hvac);
	}

	/* The arrow is the current temperature, so it takes the colour of what
	 * is being done about it rather than a colour of its own.
	 */
	lv_obj_set_style_line_color(idle_now_arrow,
				    lv_color_hex(now.hvac == DOORBELL_UI_HVAC_HEATING ? COLOUR_WARM
						 : now.hvac == DOORBELL_UI_HVAC_COOLING
							 ? COLOUR_COOL
							 : 0xffffff),
				    LV_PART_MAIN);

	for (uint32_t i = 0; i < lv_obj_get_child_count(idle_mode_row); i++) {
		lv_obj_t *btn = lv_obj_get_child(idle_mode_row, i);
		const bool selected = (enum doorbell_ui_mode)i == now.mode;

		lv_obj_set_style_bg_color(btn,
					  lv_color_hex(selected ? COLOUR_IFX_GREEN : COLOUR_TRACK),
					  LV_PART_MAIN);
	}
}

static void idle_tick(lv_timer_t *timer)
{
	ARG_UNUSED(timer);

	clock_minutes = (clock_minutes + 1) % (24 * 60);
	update_clock();
}

/*
 * Dragging a setpoint.
 *
 * Two draggable knobs on one ring is more than one lv_arc can express, and two
 * overlapping arcs fight over every touch because they occupy the same pixels.
 * So the ring is drawn by arcs that take no input at all, and a transparent
 * layer over it turns a touch into an angle and an angle into a temperature.
 *
 * Which setpoint moves is decided once, on the press, and held for the whole
 * drag. Deciding it again on every move would hand the drag over to the other
 * knob the moment the finger crossed the midpoint, which is the one thing a
 * person dragging a knob never wants.
 */
static enum { DRAG_NONE, DRAG_MIN, DRAG_MAX } dragging;

static void apply_drag(int tenths)
{
	const int celsius = (tenths + 5) / 10;

	k_mutex_lock(&thermostat_lock, K_FOREVER);

	/* A degree of separation, always. Letting them meet would make the
	 * band vanish and leave the two knobs on top of each other, which is
	 * a state there is no gesture to get back out of.
	 */
	if (dragging == DRAG_MIN) {
		thermostat.setpoint_min = CLAMP(celsius, DOORBELL_UI_TEMP_MIN,
						MIN(thermostat.setpoint_max - 1,
						    DOORBELL_UI_TEMP_MAX - 1));
	} else if (dragging == DRAG_MAX) {
		thermostat.setpoint_max = CLAMP(celsius,
						MAX(thermostat.setpoint_min + 1,
						    DOORBELL_UI_TEMP_MIN + 1),
						DOORBELL_UI_TEMP_MAX);
	}

	hvac_recompute();
	k_mutex_unlock(&thermostat_lock);

	refresh_thermostat();
}

/** Turn a touch into a temperature, or return -1 if it was not on the dial. */
static int touch_tenths(lv_event_t *e)
{
	lv_indev_t *indev = lv_event_get_indev(e);
	lv_point_t point;
	int dx;
	int dy;
	int degrees;
	int radius;

	if (indev == NULL) {
		return -1;
	}

	lv_indev_get_point(indev, &point);
	dx = point.x - DIAL_CX;
	dy = point.y - DIAL_CY;

	/* Near the centre the angle is meaningless and jumps about, but the
	 * centre of this dial is off the bottom of the screen, so in practice
	 * this only rejects a touch that is nowhere near the ring.
	 */
	radius = (int)lv_sqrt32((uint32_t)(dx * dx + dy * dy));
	if (radius < DIAL_R / 2) {
		return -1;
	}

	degrees = dial_angle_at(dx, dy);
	if (degrees < DIAL_START_DEG - 10 || degrees > DIAL_END_DEG + 10) {
		return -1;
	}

	return dial_tenths(degrees);
}

static void dial_pressed(lv_event_t *e)
{
	int tenths = touch_tenths(e);
	struct doorbell_ui_thermostat now;
	int to_min;
	int to_max;

	dragging = DRAG_NONE;

	if (tenths < 0) {
		return;
	}

	k_mutex_lock(&thermostat_lock, K_FOREVER);
	now = thermostat;
	k_mutex_unlock(&thermostat_lock);

	to_min = abs(tenths - now.setpoint_min * 10);
	to_max = abs(tenths - now.setpoint_max * 10);

	if (mode_has_min(now.mode) && mode_has_max(now.mode)) {
		dragging = to_min <= to_max ? DRAG_MIN : DRAG_MAX;
	} else if (mode_has_min(now.mode)) {
		dragging = DRAG_MIN;
	} else if (mode_has_max(now.mode)) {
		dragging = DRAG_MAX;
	} else {
		/* Off. Nothing to drag, and silently moving a hidden setpoint
		 * would be a change with no visible cause.
		 */
		return;
	}

	apply_drag(tenths);
}

static void dial_pressing(lv_event_t *e)
{
	int tenths;

	if (dragging == DRAG_NONE) {
		return;
	}

	tenths = touch_tenths(e);
	if (tenths >= 0) {
		apply_drag(tenths);
	}
}

static void dial_released(lv_event_t *e)
{
	ARG_UNUSED(e);
	dragging = DRAG_NONE;
}

#if defined(LCD_720_720)
/*
 * The GT911 on the 720x720 panel is not linear down the glass (its stored config is for
 * another panel). The devicetree scales raw 226..1017 to 0..719; these points, measured at
 * the top, quarter, middle, three quarters and bottom, bend that onto the screen.
 */
static const int16_t touch_y_in[] = {0, 79, 140, 166, 556, 600, 719};
static const int16_t touch_y_out[] = {0, 180, 251, 355, 450, 510, 719};
static lv_indev_read_cb_t touch_read_orig;

static void touch_read_cal(lv_indev_t *indev, lv_indev_data_t *data)
{
	static lv_indev_state_t prev_state = LV_INDEV_STATE_RELEASED;
	int32_t y;

	touch_read_orig(indev, data);
	y = data->point.y;
	for (size_t i = 1; i < ARRAY_SIZE(touch_y_in); i++) {
		if (y <= touch_y_in[i] || i == ARRAY_SIZE(touch_y_in) - 1) {
			y = touch_y_out[i - 1] + (y - touch_y_in[i - 1]) *
							 (touch_y_out[i] - touch_y_out[i - 1]) /
							 (touch_y_in[i] - touch_y_in[i - 1]);
			break;
		}
	}
	/* TEMP: calibration check for the ring overlay buttons. */
	if (data->state == LV_INDEV_STATE_PRESSED && prev_state != LV_INDEV_STATE_PRESSED) {
		LOG_INF("touchcal: press x=%d y_lin=%d -> y=%d", (int)data->point.x,
			(int)data->point.y, (int)CLAMP(y, 0, 719));
	}
	prev_state = data->state;
	data->point.y = CLAMP(y, 0, 719);
}
#endif

static void mode_clicked(lv_event_t *e)
{
	lv_obj_t *btn = lv_event_get_target(e);
	lv_obj_t *row = lv_obj_get_parent(btn);

	for (uint32_t i = 0; i < lv_obj_get_child_count(row); i++) {
		if (lv_obj_get_child(row, i) != btn) {
			continue;
		}

		k_mutex_lock(&thermostat_lock, K_FOREVER);
		thermostat.mode = (enum doorbell_ui_mode)i;
		hvac_recompute();
		k_mutex_unlock(&thermostat_lock);
		break;
	}

	refresh_thermostat();
}

static lv_obj_t *make_mode_button(lv_obj_t *row, const char *text)
{
	lv_obj_t *btn = lv_btn_create(row);
	lv_obj_t *label;

	lv_obj_set_size(btn, 150, 54);
	lv_obj_set_style_radius(btn, 27, LV_PART_MAIN);
	lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
	lv_obj_set_style_bg_color(btn, lv_color_hex(COLOUR_TRACK), LV_PART_MAIN);
	lv_obj_add_event_cb(btn, mode_clicked, LV_EVENT_CLICKED, NULL);

	label = lv_label_create(btn);
	lv_label_set_text(label, text);
	label_style(label, 0xffffff, &lv_font_montserrat_20);
	lv_obj_center(label);

	return btn;
}

static lv_obj_t *make_round_button(lv_obj_t *parent, const char *symbol, int size,
				   uint32_t colour, lv_event_cb_t handler)
{
	lv_obj_t *btn = lv_btn_create(parent);
	lv_obj_t *label;

	lv_obj_set_size(btn, size, size);
	lv_obj_set_style_radius(btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
	lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
	lv_obj_set_style_bg_color(btn, lv_color_hex(colour), LV_PART_MAIN);
	lv_obj_add_event_cb(btn, handler, LV_EVENT_CLICKED, NULL);

	label = lv_label_create(btn);
	lv_label_set_text(label, symbol);
	label_style(label, 0xffffff, &lv_font_montserrat_20);
	lv_obj_center(label);

	return btn;
}

static void stats_open(lv_event_t *e);
static void stats_close(lv_event_t *e);

/** A dial arc: the track, or the coloured band over it. Never clickable. */
static lv_obj_t *make_dial_arc(uint32_t colour, bool indicator)
{
	lv_obj_t *arc = lv_arc_create(idle_screen);

	lv_obj_set_size(arc, DIAL_R * 2, DIAL_R * 2);
	lv_obj_set_pos(arc, DIAL_CX - DIAL_R, DIAL_CY - DIAL_R);

	/* The arc is a full circle 800 px across centred below the middle of
	 * the panel, so only the sweep from 200 to 340 degrees is ever on the
	 * glass and the bottom half hangs off by design. Say so, rather than
	 * let the layout check count it and teach everyone to ignore a
	 * non-zero result.
	 */
	lv_obj_add_flag(arc, LAYOUT_OVERSIZE_BY_DESIGN);
	lv_arc_set_rotation(arc, 0);
	lv_arc_set_bg_angles(arc, DIAL_START_DEG, DIAL_END_DEG);
	lv_obj_set_style_arc_width(arc, DIAL_ARC_W, LV_PART_MAIN);
	lv_obj_set_style_arc_width(arc, DIAL_ARC_W, LV_PART_INDICATOR);
	lv_obj_set_style_arc_rounded(arc, true, LV_PART_MAIN);
	lv_obj_set_style_arc_rounded(arc, true, LV_PART_INDICATOR);
	lv_obj_remove_style(arc, NULL, LV_PART_KNOB);
	lv_obj_remove_flag(arc, LV_OBJ_FLAG_CLICKABLE);

	if (indicator) {
		/* The track underneath is already drawing the dim ring; a
		 * second one on top of it would darken it by half.
		 */
		lv_obj_set_style_arc_opa(arc, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_arc_color(arc, lv_color_hex(colour), LV_PART_INDICATOR);
	} else {
		lv_obj_set_style_arc_color(arc, lv_color_hex(colour), LV_PART_MAIN);
		lv_obj_set_style_arc_opa(arc, LV_OPA_TRANSP, LV_PART_INDICATOR);
	}

	return arc;
}

static lv_obj_t *make_knob(uint32_t colour)
{
	lv_obj_t *knob = lv_obj_create(idle_screen);

	lv_obj_set_size(knob, 40, 40);
	lv_obj_set_style_radius(knob, LV_RADIUS_CIRCLE, LV_PART_MAIN);
	lv_obj_set_style_bg_color(knob, lv_color_hex(colour), LV_PART_MAIN);
	lv_obj_set_style_border_color(knob, lv_color_hex(0xffffff), LV_PART_MAIN);
	lv_obj_set_style_border_width(knob, 3, LV_PART_MAIN);
	lv_obj_set_style_pad_all(knob, 0, LV_PART_MAIN);
	lv_obj_remove_flag(knob, LV_OBJ_FLAG_SCROLLABLE);
	lv_obj_remove_flag(knob, LV_OBJ_FLAG_CLICKABLE);

	return knob;
}

static void build_idle_screen(void)
{
	lv_obj_t *touch;

	idle_screen = make_screen();
	lv_obj_set_style_bg_color(idle_screen, lv_color_hex(COLOUR_INK), LV_PART_MAIN);
	lv_obj_clear_flag(idle_screen, LV_OBJ_FLAG_SCROLLABLE);
	lv_obj_set_style_pad_all(idle_screen, 0, LV_PART_MAIN);

	/* On the screen, not on the root: LVGL delivers the screen load and
	 * unload events to the screen object itself, and a handler attached to
	 * a child of it is never called. This is what stopped the artwork --
	 * the timer that advances it is started here, so the picture composed
	 * and repainted forever at phase zero and the leaves stood still.
	 */
	lv_obj_add_event_cb(screen_of(idle_screen), art_screen_loaded,
			    LV_EVENT_SCREEN_LOADED, NULL);
	lv_obj_add_event_cb(screen_of(idle_screen), art_screen_unloaded,
			    LV_EVENT_SCREEN_UNLOADED, NULL);

	/*
	 * The background artwork. First child, so everything else is painted
	 * over it, and transparent, so what shows through it is the screen's
	 * own colour rather than a fill of ours that has to match it.
	 */
	idle_art = lv_obj_create(idle_screen);
	lv_obj_set_pos(idle_art, 0, 0);
	lv_obj_set_size(idle_art, panel_w, panel_h);
	lv_obj_set_style_bg_opa(idle_art, LV_OPA_TRANSP, LV_PART_MAIN);
	lv_obj_set_style_border_width(idle_art, 0, LV_PART_MAIN);
	lv_obj_remove_flag(idle_art, LV_OBJ_FLAG_SCROLLABLE);
	lv_obj_remove_flag(idle_art, LV_OBJ_FLAG_CLICKABLE);
	lv_obj_add_event_cb(idle_art, art_draw_cb, LV_EVENT_DRAW_MAIN_END, NULL);

	/* Painted back to front: the dim track, the coloured band the
	 * thermostat is holding, then the arrow and the knobs on top of both.
	 */
	idle_track = make_dial_arc(COLOUR_TRACK, false);
	idle_band = make_dial_arc(COLOUR_IFX_GREEN, true);

	idle_now_arrow = lv_line_create(idle_screen);
	lv_obj_set_pos(idle_now_arrow, 0, 0);
	lv_obj_set_size(idle_now_arrow, panel_w, panel_h);
	lv_obj_set_style_line_width(idle_now_arrow, 4, LV_PART_MAIN);
	lv_obj_set_style_line_rounded(idle_now_arrow, true, LV_PART_MAIN);
	lv_obj_set_style_line_color(idle_now_arrow, lv_color_hex(0xffffff), LV_PART_MAIN);

	idle_knob_min = make_knob(COLOUR_WARM);
	idle_knob_max = make_knob(COLOUR_COOL);
	idle_knob_min_label = make_label(idle_screen, "", COLOUR_WARM, &lv_font_montserrat_20);
	idle_knob_max_label = make_label(idle_screen, "", COLOUR_COOL, &lv_font_montserrat_20);

	/* The reading, inside the dial where the eye goes first. */
	idle_temp_label = make_label(idle_screen, "--", 0xffffff, &lv_font_montserrat_48);
	idle_unit_label = make_label(idle_screen, "°C", COLOUR_DIM, &lv_font_montserrat_20);

	idle_hvac_label = make_label(idle_screen, "idle", COLOUR_DIM, &lv_font_montserrat_20);
	lv_obj_align(idle_hvac_label, LV_ALIGN_TOP_MID, 0, 278);

	idle_clock_label = make_label(idle_screen, "00:00", 0xffffff, &lv_font_montserrat_28);
	lv_obj_align(idle_clock_label, LV_ALIGN_TOP_LEFT, 18, 14);
	update_clock();

	idle_humidity_label = make_label(idle_screen, "", COLOUR_DIM, &lv_font_montserrat_20);
	lv_obj_align(idle_humidity_label, LV_ALIGN_TOP_RIGHT, -18, 18);

	/*
	 * The touch layer. Over the dial and under nothing, so it sees every
	 * press on the ring; the arcs below it take no input of their own.
	 */
	touch = lv_obj_create(idle_screen);
	lv_obj_set_pos(touch, 0, 0);
	lv_obj_set_size(touch, panel_w, 300);
	lv_obj_set_style_bg_opa(touch, LV_OPA_TRANSP, LV_PART_MAIN);
	lv_obj_set_style_border_width(touch, 0, LV_PART_MAIN);
	lv_obj_remove_flag(touch, LV_OBJ_FLAG_SCROLLABLE);
	lv_obj_add_flag(touch, LV_OBJ_FLAG_CLICKABLE);
	lv_obj_add_event_cb(touch, dial_pressed, LV_EVENT_PRESSED, NULL);
	lv_obj_add_event_cb(touch, dial_pressing, LV_EVENT_PRESSING, NULL);
	lv_obj_add_event_cb(touch, dial_released, LV_EVENT_RELEASED, NULL);
	lv_obj_add_event_cb(touch, dial_released, LV_EVENT_PRESS_LOST, NULL);

	/* The controls, under the dial. The order of the buttons is the order
	 * of enum doorbell_ui_mode, which is what lets a press be turned into
	 * a mode by its position in the row.
	 */
	idle_mode_row = lv_obj_create(idle_screen);
	lv_obj_set_size(idle_mode_row, 680, 66);
	lv_obj_align(idle_mode_row, LV_ALIGN_TOP_MID, 0, 318);
	lv_obj_set_style_bg_opa(idle_mode_row, LV_OPA_TRANSP, LV_PART_MAIN);
	lv_obj_set_style_border_width(idle_mode_row, 0, LV_PART_MAIN);
	lv_obj_set_style_pad_all(idle_mode_row, 0, LV_PART_MAIN);
	lv_obj_set_flex_flow(idle_mode_row, LV_FLEX_FLOW_ROW);
	lv_obj_set_flex_align(idle_mode_row, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER,
			      LV_FLEX_ALIGN_CENTER);
	lv_obj_clear_flag(idle_mode_row, LV_OBJ_FLAG_SCROLLABLE);

	make_mode_button(idle_mode_row, doorbell_ui_mode_name(DOORBELL_UI_MODE_OFF));
	make_mode_button(idle_mode_row, doorbell_ui_mode_name(DOORBELL_UI_MODE_HEAT));
	make_mode_button(idle_mode_row, doorbell_ui_mode_name(DOORBELL_UI_MODE_COOL));
	make_mode_button(idle_mode_row, doorbell_ui_mode_name(DOORBELL_UI_MODE_AUTO));

	idle_status_label = make_label(idle_screen, "starting...", COLOUR_DIM,
				       &lv_font_montserrat_14);
	lv_obj_align(idle_status_label, LV_ALIGN_BOTTOM_LEFT, 24, -16);

	make_round_button(idle_screen, LV_SYMBOL_SETTINGS, 44, COLOUR_TRACK, stats_open);
	lv_obj_align(lv_obj_get_child(idle_screen, lv_obj_get_child_count(idle_screen) - 1),
		     LV_ALIGN_BOTTOM_RIGHT, -24, -12);

	refresh_thermostat();

	lv_timer_create(idle_tick, 1000, NULL);
}

/*
 * 3. Ring -- an overlay over the thermostat, not a screen of its own.
 */
static void build_incoming_overlay(void)
{
	lv_obj_t *card;
	lv_obj_t *title;

	incoming_overlay = lv_obj_create(idle_screen);
	lv_obj_set_size(incoming_overlay, panel_w, panel_h);
	lv_obj_center(incoming_overlay);
	lv_obj_set_style_bg_color(incoming_overlay, lv_color_black(), LV_PART_MAIN);
	lv_obj_set_style_bg_opa(incoming_overlay, LV_OPA_70, LV_PART_MAIN);
	lv_obj_set_style_border_width(incoming_overlay, 0, LV_PART_MAIN);
	lv_obj_set_style_radius(incoming_overlay, 0, LV_PART_MAIN);
	lv_obj_clear_flag(incoming_overlay, LV_OBJ_FLAG_SCROLLABLE);
	lv_obj_add_flag(incoming_overlay, LV_OBJ_FLAG_HIDDEN);

	card = lv_obj_create(incoming_overlay);
	lv_obj_set_size(card, 560, 300);
	lv_obj_center(card);
	lv_obj_set_style_bg_color(card, lv_color_hex(0x16202a), LV_PART_MAIN);
	lv_obj_set_style_border_width(card, 0, LV_PART_MAIN);
	lv_obj_set_style_radius(card, 24, LV_PART_MAIN);
	lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);

	title = make_label(card, "Someone is at the door", 0xffffff, &lv_font_montserrat_28);
	lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 24);

	incoming_peer_label = make_label(card, "", COLOUR_DIM, &lv_font_montserrat_14);
	lv_obj_align(incoming_peer_label, LV_ALIGN_TOP_MID, 0, 70);

	incoming_time_label = make_label(card, "", COLOUR_DIM, &lv_font_montserrat_20);
	lv_obj_align(incoming_time_label, LV_ALIGN_TOP_MID, 0, 96);

	make_action_button(card, "Answer", lv_color_hex(COLOUR_GREEN), LV_ALIGN_BOTTOM_LEFT,
			   answer_clicked);
	make_action_button(card, "Ignore", lv_color_hex(COLOUR_RED), LV_ALIGN_BOTTOM_RIGHT,
			   hangup_clicked);
}

/*
 * 4. In call -- the picture, and one round button.
 */
static void build_call_screen(void)
{
	lv_obj_t *hangup;

	call_screen = make_screen();
	lv_obj_set_style_bg_color(call_screen, lv_color_black(), LV_PART_MAIN);
	lv_obj_set_style_pad_all(call_screen, 0, LV_PART_MAIN);
	lv_obj_clear_flag(call_screen, LV_OBJ_FLAG_SCROLLABLE);

	video_image = lv_image_create(call_screen);
	lv_obj_center(video_image);

	/* Scale on the way to the panel rather than decoding larger: VG-Lite
	 * does the stretch, so a bigger picture costs no decode time.
	 */

	call_stats_label = make_label(call_screen, "", 0xd0d8e0, &lv_font_montserrat_10);
	lv_obj_set_style_bg_color(call_stats_label, lv_color_black(), LV_PART_MAIN);
	lv_obj_set_style_bg_opa(call_stats_label, LV_OPA_50, LV_PART_MAIN);
	lv_obj_set_style_pad_all(call_stats_label, 6, LV_PART_MAIN);
	lv_obj_align(call_stats_label, LV_ALIGN_TOP_LEFT, 12, 12);

	/* Created after the image so it stays on top of it. */
	hangup = make_round_button(call_screen, LV_SYMBOL_CLOSE, 64, COLOUR_RED, hangup_clicked);
	lv_obj_align(hangup, LV_ALIGN_BOTTOM_RIGHT, -24, -24);
}

/*
 * 5. Smoke-alarm alert -- a flashing red border and a central warning symbol,
 *    on the top layer so it shows over any screen.
 */
#define ALARM_HOLD_MS   10000
#define ALARM_FLASH_MS  400
#define ALARM_BORDER_PX 16
#define COLOUR_ALARM    0xff0000

/* The warning symbol is drawn from primitives, not a font glyph: a red triangle
 * with a white border (see alarm_draw_symbol) and a white exclamation mark -- a
 * rectangle bar over a square dot -- in its lower half.
 */
#define ALARM_TRI_W      180
#define ALARM_TRI_H      156
#define ALARM_TRI_STROKE 10 /* white border width */
#define ALARM_MARK_W     16 /* bar width and square side */
#define ALARM_MARK_BAR_H 48
#define ALARM_MARK_BAR_Y 8  /* bar centre, below the frame centre */
#define ALARM_MARK_DOT_Y 46 /* square centre, below the bar */

/* Filled at build time in frame coordinates; read by the draw callback. */
static lv_point_precise_t alarm_triangle[4];

static void alarm_tick(lv_timer_t *timer)
{
	ARG_UNUSED(timer);

	if (k_uptime_get() >= alarm_deadline) {
		lv_obj_add_flag(alarm_border, LV_OBJ_FLAG_HIDDEN);
		lv_timer_pause(alarm_timer);
		return;
	}

	alarm_flash_on = !alarm_flash_on;
	lv_obj_set_style_border_opa(alarm_border, alarm_flash_on ? LV_OPA_COVER : LV_OPA_TRANSP,
				    LV_PART_MAIN);
}

static void alarm_show(void)
{
	alarm_deadline = k_uptime_get() + ALARM_HOLD_MS;

	if (lv_obj_has_flag(alarm_border, LV_OBJ_FLAG_HIDDEN)) {
		alarm_flash_on = true;
		lv_obj_set_style_border_opa(alarm_border, LV_OPA_COVER, LV_PART_MAIN);
		lv_obj_clear_flag(alarm_border, LV_OBJ_FLAG_HIDDEN);
		lv_obj_move_foreground(alarm_border);
	}

	lv_timer_resume(alarm_timer);
}

/* Draws the warning triangle: a red fill with a white border. The white
 * exclamation mark (bar + dot child objects) renders on top of it. Runs each
 * frame while the frame is visible, so the symbol never flashes with the border.
 */
static void alarm_draw_symbol(lv_event_t *e)
{
	lv_obj_t *obj = lv_event_get_target(e);
	lv_layer_t *layer = lv_event_get_layer(e);
	lv_area_t coords;
	lv_draw_triangle_dsc_t fill;
	lv_draw_line_dsc_t edge;

	lv_obj_get_coords(obj, &coords);

	lv_draw_triangle_dsc_init(&fill);
	fill.color = lv_color_hex(COLOUR_ALARM);
	fill.opa = LV_OPA_COVER;
	for (int i = 0; i < 3; i++) {
		fill.p[i].x = coords.x1 + alarm_triangle[i].x;
		fill.p[i].y = coords.y1 + alarm_triangle[i].y;
	}
	lv_draw_triangle(layer, &fill);

	lv_draw_line_dsc_init(&edge);
	edge.color = lv_color_white();
	edge.width = ALARM_TRI_STROKE;
	edge.opa = LV_OPA_COVER;
	edge.round_start = 1;
	edge.round_end = 1;
	for (int i = 0; i < 3; i++) {
		edge.p1.x = coords.x1 + alarm_triangle[i].x;
		edge.p1.y = coords.y1 + alarm_triangle[i].y;
		edge.p2.x = coords.x1 + alarm_triangle[i + 1].x;
		edge.p2.y = coords.y1 + alarm_triangle[i + 1].y;
		lv_draw_line(layer, &edge);
	}
}

static void build_alarm_overlay(void)
{
	lv_obj_t *top = lv_layer_top();
	lv_obj_t *bar;
	lv_obj_t *dot;

	alarm_border = lv_obj_create(top);
	lv_obj_remove_style_all(alarm_border);
	lv_obj_set_size(alarm_border, panel_w, panel_h);
	lv_obj_align(alarm_border, LV_ALIGN_TOP_LEFT, 0, 0);
	lv_obj_set_style_bg_opa(alarm_border, LV_OPA_TRANSP, LV_PART_MAIN);
	lv_obj_set_style_border_color(alarm_border, lv_color_hex(COLOUR_ALARM), LV_PART_MAIN);
	lv_obj_set_style_border_width(alarm_border, ALARM_BORDER_PX, LV_PART_MAIN);
	lv_obj_set_style_border_opa(alarm_border, LV_OPA_COVER, LV_PART_MAIN);
	/* Non-interactive: the alert must not swallow touches meant for the UI. */
	lv_obj_clear_flag(alarm_border, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);
	lv_obj_add_flag(alarm_border, LV_OBJ_FLAG_HIDDEN);

	/* All three are children of the frame, so they sit over the glass centre
	 * and stay steady while the border blinks.
	 */
	alarm_triangle[0].x = panel_w / 2;
	alarm_triangle[0].y = panel_h / 2 - ALARM_TRI_H / 2;
	alarm_triangle[1].x = panel_w / 2 - ALARM_TRI_W / 2;
	alarm_triangle[1].y = panel_h / 2 + ALARM_TRI_H / 2;
	alarm_triangle[2].x = panel_w / 2 + ALARM_TRI_W / 2;
	alarm_triangle[2].y = panel_h / 2 + ALARM_TRI_H / 2;
	alarm_triangle[3] = alarm_triangle[0];

	/* The frame itself draws the filled triangle (see alarm_draw_symbol); the
	 * bar and dot are children so they render in white on top of it.
	 */
	lv_obj_add_event_cb(alarm_border, alarm_draw_symbol, LV_EVENT_DRAW_MAIN_END, NULL);

	bar = lv_obj_create(alarm_border);
	lv_obj_remove_style_all(bar);
	lv_obj_set_size(bar, ALARM_MARK_W, ALARM_MARK_BAR_H);
	lv_obj_set_style_bg_color(bar, lv_color_white(), LV_PART_MAIN);
	lv_obj_set_style_bg_opa(bar, LV_OPA_COVER, LV_PART_MAIN);
	lv_obj_align(bar, LV_ALIGN_CENTER, 0, ALARM_MARK_BAR_Y);
	lv_obj_clear_flag(bar, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);

	dot = lv_obj_create(alarm_border);
	lv_obj_remove_style_all(dot);
	lv_obj_set_size(dot, ALARM_MARK_W, ALARM_MARK_W);
	lv_obj_set_style_bg_color(dot, lv_color_white(), LV_PART_MAIN);
	lv_obj_set_style_bg_opa(dot, LV_OPA_COVER, LV_PART_MAIN);
	lv_obj_align(dot, LV_ALIGN_CENTER, 0, ALARM_MARK_DOT_Y);
	lv_obj_clear_flag(dot, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);

	alarm_timer = lv_timer_create(alarm_tick, ALARM_FLASH_MS, NULL);
	lv_timer_pause(alarm_timer);
}

/*
 * Statistics.
 *
 * Sampled by a timer on the LVGL thread, never pushed from the receive path.
 * Phase 3 established that logging in the receive path causes the loss it
 * reports, and a UI update from there would be the same mistake wearing a
 * different hat. Everything read here already exists; this is presentation.
 */
static void format_stats(char *buf, size_t len, bool compact)
{
	struct doorbell_video_stats video;
	struct doorbell_decode_stats decode;
	struct doorbell_rtp_stats audio;
	uint32_t panel_last, panel_mean, panel_worst;
	unsigned int kbps = 0;

	doorbell_video_get_stats(&video);
	doorbell_decode_get_stats(&decode);
	doorbell_rtp_get_stats(&audio);
	doorbell_ui_frame_latency(&panel_last, &panel_mean, &panel_worst);

	if (video.elapsed_ms > 0) {
		kbps = (unsigned int)((uint64_t)video.bytes * 8U / video.elapsed_ms);
	}

	if (compact) {
		snprintk(buf, len,
			 "%ux%u  %u kbit/s\n"
			 "au %u  lost %u  held %u\n"
			 "dec %u ms  panel %u ms\n"
			 "audio %u/%u",
			 decode.width, decode.height, kbps, video.frames, video.lost,
			 video.frames_skipped, decode.mean_us / 1000U, panel_mean / 1000U,
			 audio.received, audio.lost);
		return;
	}

	snprintk(buf, len,
		 "network\n"
		 "  packets   %u received, %u lost\n"
		 "  units     %u intact, %u broken\n"
		 "  recovery  %u held back, %u key frames asked for\n"
		 "  rate      %u kbit/s over %u ms\n"
		 "audio\n"
		 "  rtp       %u received, %u lost, %u concealed\n"
		 "  talkback  %u sent\n"
		 "decode\n"
		 "  pictures  %u at %ux%u, %u concealed mbs\n"
		 "  queue     %u deepest, %u dropped\n"
		 "  time      %u us mean, %u us worst\n"
		 "display\n"
		 "  frames    %u drawn\n"
		 "  to panel  %u us mean, %u us worst",
		 video.packets, video.lost, video.frames, video.frames_broken,
		 video.frames_skipped, video.keyframe_requests, kbps, video.elapsed_ms,
		 audio.received, audio.lost, audio.concealed, audio.sent,
		 decode.pictures, decode.width, decode.height, decode.concealed,
		 decode.queued_worst, decode.dropped, decode.mean_us, decode.worst_us,
		 doorbell_ui_frames_shown(), panel_mean, panel_worst);
}

static void stats_tick(lv_timer_t *timer)
{
	char buf[768];

	ARG_UNUSED(timer);

	if (stats_overlay != NULL && !lv_obj_has_flag(stats_overlay, LV_OBJ_FLAG_HIDDEN)) {
		format_stats(buf, sizeof(buf), false);
		lv_label_set_text(stats_page_label, buf);
	}

	if (call_stats_label != NULL && lv_scr_act() == screen_of(call_screen)) {
		format_stats(buf, sizeof(buf), true);
		lv_label_set_text(call_stats_label, buf);
	}
}

static void stats_close(lv_event_t *e)
{
	ARG_UNUSED(e);

	lv_obj_add_flag(stats_overlay, LV_OBJ_FLAG_HIDDEN);
}

static void stats_open(lv_event_t *e)
{
	char buf[768];

	ARG_UNUSED(e);

	/* Filled in before it is shown, so it never appears empty for a second. */
	format_stats(buf, sizeof(buf), false);
	lv_label_set_text(stats_page_label, buf);
	lv_obj_clear_flag(stats_overlay, LV_OBJ_FLAG_HIDDEN);
	lv_obj_move_foreground(stats_overlay);
}

static void build_stats_overlay(void)
{
	lv_obj_t *title;

	stats_overlay = lv_obj_create(idle_screen);
	lv_obj_set_size(stats_overlay, panel_w, panel_h);
	lv_obj_center(stats_overlay);
	lv_obj_set_style_bg_color(stats_overlay, lv_color_hex(0x0a1017), LV_PART_MAIN);
	lv_obj_set_style_bg_opa(stats_overlay, LV_OPA_COVER, LV_PART_MAIN);
	lv_obj_set_style_border_width(stats_overlay, 0, LV_PART_MAIN);
	lv_obj_set_style_radius(stats_overlay, 0, LV_PART_MAIN);
	lv_obj_clear_flag(stats_overlay, LV_OBJ_FLAG_SCROLLABLE);
	lv_obj_add_flag(stats_overlay, LV_OBJ_FLAG_HIDDEN);

	title = make_label(stats_overlay, "Statistics", 0xffffff, &lv_font_montserrat_20);
	lv_obj_align(title, LV_ALIGN_TOP_LEFT, 24, 16);

	stats_page_label = make_label(stats_overlay, "", 0xd0d8e0, &lv_font_montserrat_14);
	lv_obj_align(stats_page_label, LV_ALIGN_TOP_LEFT, 24, 52);

	make_round_button(stats_overlay, LV_SYMBOL_CLOSE, 56, 0x1c2a36, stats_close);
	lv_obj_align(lv_obj_get_child(stats_overlay, lv_obj_get_child_count(stats_overlay) - 1),
		     LV_ALIGN_TOP_RIGHT, -24, 16);

	lv_timer_create(stats_tick, 1000, NULL);
}

/*
 * Boot progress.
 */
static void boot_step(uint8_t item, bool ok, const char *value)
{
	if (item >= DOORBELL_UI_BOOT_ITEMS || boot_values[item] == NULL) {
		return;
	}

	lv_label_set_text(boot_values[item], value != NULL && value[0] ? value : "...");
	label_style(boot_values[item], ok ? COLOUR_INK : COLOUR_RED, &lv_font_montserrat_20);
}

static void boot_done(void)
{
	if (lv_scr_act() != screen_of(boot_screen)) {
		return;
	}

	lv_scr_load_anim(screen_of(idle_screen), LV_SCR_LOAD_ANIM_FADE_IN, 400, 0, false);
}

static void handle_cmd(const struct ui_cmd *cmd)
{
	switch (cmd->type) {
	case UI_CMD_SET_STATUS:
		lv_label_set_text(idle_status_label, cmd->text);
		break;
	case UI_CMD_SHOW_INCOMING: {
		char when[16];

		lv_label_set_text(incoming_peer_label, cmd->text);
		snprintk(when, sizeof(when), "%02d:%02d", (clock_minutes / 60) % 24,
			 clock_minutes % 60);
		lv_label_set_text(incoming_time_label, when);

		/* The thermostat stays underneath, so make sure it is the
		 * screen the overlay is dimming.
		 */
		lv_scr_load(screen_of(idle_screen));
		lv_obj_add_flag(stats_overlay, LV_OBJ_FLAG_HIDDEN);
		lv_obj_clear_flag(incoming_overlay, LV_OBJ_FLAG_HIDDEN);
		lv_obj_move_foreground(incoming_overlay);
		break;
	}
	case UI_CMD_SHOW_STATS:
		if (cmd->ok) {
			stats_open(NULL);
		} else {
			stats_close(NULL);
		}
		break;
	case UI_CMD_SHOW_IDLE:
		lv_obj_add_flag(incoming_overlay, LV_OBJ_FLAG_HIDDEN);
		lv_scr_load(screen_of(idle_screen));
		break;
	case UI_CMD_BOOT_STEP:
		boot_step(cmd->item, cmd->ok, cmd->text);
		break;
	case UI_CMD_BOOT_DONE:
		boot_done();
		break;
	case UI_CMD_ANSWER:
		do_answer();
		break;
	case UI_CMD_DECLINE:
		do_decline();
		break;
	case UI_CMD_THERMOSTAT:
		refresh_thermostat();
		break;
	case UI_CMD_SHOW_FRAME:
		show_frame();
		break;
	case UI_CMD_LAYOUT_CHECK:
		layout_check_run();
		break;

	case UI_CMD_BENCH_SCREEN:
		/* The call screen without a call: the benchmark needs the video
		 * image on the glass, but must not tell the far end anything.
		 */
		lv_scr_load(screen_of(cmd->ok ? call_screen : idle_screen));
		break;
	case UI_CMD_ALARM_ALERT:
		alarm_show();
		break;
	default:
		LOG_WRN("unknown UI command %d", (int)cmd->type);
		break;
	}
}

static void ui_thread_fn(void *p1, void *p2, void *p3)
{
	ARG_UNUSED(p1);
	ARG_UNUSED(p2);
	ARG_UNUSED(p3);

	while (true) {
		struct ui_cmd cmd;
		uint32_t sleep_ms;

		uint32_t began = k_cycle_get_32();
		uint32_t spent;

		sleep_ms = lv_timer_handler();

		spent = k_cyc_to_us_floor32(k_cycle_get_32() - began);
		ui_handler_total_us += spent;
		ui_handler_calls++;
		if (spent > ui_handler_worst_us) {
			ui_handler_worst_us = spent;
		}

		/* lv_timer_handler() returns LV_NO_TIMER_READY when it has no
		 * further work; cap the wait so queued commands stay responsive.
		 */
		if (sleep_ms == LV_NO_TIMER_READY || sleep_ms > UI_MAX_SLEEP_MS) {
			sleep_ms = UI_MAX_SLEEP_MS;
		}

		/* Wait *on the queue* for that long rather than sleeping blind.
		 *
		 * This used to drain the queue and then k_msleep(), which meant
		 * a picture finishing decode one microsecond after the sleep
		 * began sat untouched for the whole interval: up to 20 ms of
		 * latency, 10 ms of it on average, for a frame that was ready
		 * the entire time. It was the largest single contributor to the
		 * time between a frame arriving and it being drawn, and it was
		 * invisible because it is not work -- the profile showed the
		 * CPU three-quarters idle precisely because it was asleep
		 * holding a finished frame.
		 */
		if (ui_blind_sleep) {
			/* The old behaviour, kept behind a switch so the two
			 * can be compared on the same silicon in the same run
			 * rather than across two flashes.
			 */
			k_msleep(sleep_ms);
			while (k_msgq_get(&ui_msgq, &cmd, K_NO_WAIT) == 0) {
				handle_cmd(&cmd);
			}
			continue;
		}

		if (k_msgq_get(&ui_msgq, &cmd, K_MSEC(sleep_ms)) == 0) {
			handle_cmd(&cmd);

			/* Take anything else already waiting in the same pass. */
			while (k_msgq_get(&ui_msgq, &cmd, K_NO_WAIT) == 0) {
				handle_cmd(&cmd);
			}
		}
	}
}

int doorbell_ui_init(doorbell_ui_answer_cb_t cb)
{
	const struct device *display = DEVICE_DT_GET(DT_CHOSEN(zephyr_display));
	k_tid_t tid;

	answer_cb = cb;

	if (!device_is_ready(display)) {
		LOG_ERR("display device not ready");
		return -ENODEV;
	}

	panel_size_init();

	build_boot_screen();
	build_idle_screen();
	build_incoming_overlay();
	build_stats_overlay();
	build_call_screen();
	build_alarm_overlay();

#if defined(LCD_720_720)
	if (lv_indev_get_next(NULL) != NULL) {
		touch_read_orig = lv_indev_get_read_cb(lv_indev_get_next(NULL));
		lv_indev_set_read_cb(lv_indev_get_next(NULL), touch_read_cal);
	}

	/* Single-buffered here, so redraw only dirty areas in place rather than clearing and
	 * repainting the whole frame the panel is scanning out every animation tick.
	 */
	lv_display_set_render_mode(lv_display_get_default(), LV_DISPLAY_RENDER_MODE_DIRECT);
	lv_display_add_event_cb(lv_display_get_default(), render_start_cb, LV_EVENT_RENDER_START,
				NULL);
#endif

	lv_display_add_event_cb(lv_display_get_default(), render_ready_cb, LV_EVENT_RENDER_READY,
				NULL);

	lv_scr_load(screen_of(boot_screen));

	/* Render before unblanking so the panel never shows uninitialised
	 * memory. Twice, because this display is configured double buffered
	 * with a full refresh: one pass fills the buffer being scanned out and
	 * leaves the other one full of whatever was in GFX_MEMORY at reset,
	 * which showed up as garbage across the top half of the boot screen the
	 * moment the first frame was swapped in.
	 */
	lv_refr_now(NULL);
	lv_obj_invalidate(lv_screen_active());
	lv_refr_now(NULL);

	display_blanking_off(display);

	tid = k_thread_create(&ui_thread, ui_stack, UI_STACK_SIZE, ui_thread_fn, NULL, NULL, NULL,
			      UI_PRIORITY, 0, K_NO_WAIT);
	if (tid == NULL) {
		return -ENOMEM;
	}

	k_thread_name_set(tid, "doorbell_ui");

	tid = k_thread_create(&action_thread, action_stack, ACTION_STACK_SIZE, action_thread_fn,
			      NULL, NULL, NULL, ACTION_PRIORITY, 0, K_NO_WAIT);
	if (tid == NULL) {
		return -ENOMEM;
	}

	k_thread_name_set(tid, "doorbell_action");

	/* After the display is up, so vg_lite has been initialised and the
	 * feature query answers for the hardware rather than the build.
	 */
	video_use_yuy2 = vg_lite_query_feature(gcFEATURE_BIT_VG_YUY2_INPUT) ? true : false;

	LOG_INF("display up, boot screen shown");
	LOG_INF("video is converted %s",
		video_use_yuy2 ? "by the GPU, from YUY2" : "on the CPU, to RGB565");

	return 0;
}

void doorbell_ui_set_status(const char *status)
{
	post(UI_CMD_SET_STATUS, status);
}

void doorbell_ui_show_incoming(const char *peer)
{
	post(UI_CMD_SHOW_INCOMING, peer);
}

void doorbell_ui_alarm_alert(void)
{
	post(UI_CMD_ALARM_ALERT, NULL);
}

void doorbell_ui_thermostat_get(struct doorbell_ui_thermostat *out)
{
	k_mutex_lock(&thermostat_lock, K_FOREVER);
	*out = thermostat;
	k_mutex_unlock(&thermostat_lock);
}

void doorbell_ui_set_mode(enum doorbell_ui_mode mode)
{
	k_mutex_lock(&thermostat_lock, K_FOREVER);
	thermostat.mode = mode;
	hvac_recompute();
	k_mutex_unlock(&thermostat_lock);

	/* The state is already changed; this only asks the LVGL thread to
	 * redraw. Touching the widgets from here would be a second thread in
	 * LVGL, which is the one thing it does not survive.
	 */
	post(UI_CMD_THERMOSTAT, NULL);
}

void doorbell_ui_set_setpoint(bool maximum, int celsius)
{
	k_mutex_lock(&thermostat_lock, K_FOREVER);

	if (maximum) {
		thermostat.setpoint_max = CLAMP(celsius,
						MAX(thermostat.setpoint_min + 1,
						    DOORBELL_UI_TEMP_MIN + 1),
						DOORBELL_UI_TEMP_MAX);
	} else {
		thermostat.setpoint_min = CLAMP(celsius, DOORBELL_UI_TEMP_MIN,
						MIN(thermostat.setpoint_max - 1,
						    DOORBELL_UI_TEMP_MAX - 1));
	}

	hvac_recompute();
	k_mutex_unlock(&thermostat_lock);

	post(UI_CMD_THERMOSTAT, NULL);
}

void doorbell_ui_set_temperature(int tenths)
{
	k_mutex_lock(&thermostat_lock, K_FOREVER);
	thermostat.temperature_tenths = tenths;
	hvac_recompute();
	k_mutex_unlock(&thermostat_lock);

	post(UI_CMD_THERMOSTAT, NULL);
}

void doorbell_ui_show_idle(void)
{
	post(UI_CMD_SHOW_IDLE, NULL);
}

/* The overlay is normally reached by tapping the gear, which a test script
 * cannot do. This is the same path, minus the finger.
 */
void doorbell_ui_show_stats(bool shown)
{
	struct ui_cmd cmd = {
		.type = UI_CMD_SHOW_STATS,
		.ok = shown,
	};

	(void)k_msgq_put(&ui_msgq, &cmd, K_NO_WAIT);
}

void doorbell_ui_bench_screen(bool on)
{
	struct ui_cmd cmd = {
		.type = UI_CMD_BENCH_SCREEN,
		.ok = on,
	};

	(void)k_msgq_put(&ui_msgq, &cmd, K_NO_WAIT);
}

void doorbell_ui_answer(enum doorbell_ui_answer answer)
{
	/* Routed through the queue rather than called directly: LVGL is not
	 * thread safe and the caller is usually the shell thread.
	 */
	post(answer == DOORBELL_UI_ANSWERED ? UI_CMD_ANSWER : UI_CMD_DECLINE, NULL);
}

void doorbell_ui_boot_step(enum doorbell_ui_boot_item item, bool ok, const char *value)
{
	struct ui_cmd cmd = {.type = UI_CMD_BOOT_STEP, .item = (uint8_t)item, .ok = ok};

	if (value != NULL) {
		strncpy(cmd.text, value, sizeof(cmd.text) - 1);
	}

	if (k_msgq_put(&ui_msgq, &cmd, K_NO_WAIT) != 0) {
		LOG_WRN("UI queue full, dropping boot step %d", (int)item);
	}
}

void doorbell_ui_boot_done(void)
{
	/* A boot fast enough to flash past reads as a glitch rather than as
	 * progress, so hold the screen long enough to be read.
	 */
	post(UI_CMD_BOOT_DONE, NULL);
}

int doorbell_ui_layout_check(struct doorbell_ui_layout *out)
{
	struct ui_cmd cmd = {
		.type = UI_CMD_LAYOUT_CHECK,
	};

	if (out == NULL) {
		return -EINVAL;
	}

	k_sem_reset(&layout_done);
	if (k_msgq_put(&ui_msgq, &cmd, K_NO_WAIT) != 0) {
		return -EAGAIN;
	}

	if (k_sem_take(&layout_done, K_SECONDS(5)) != 0) {
		return -ETIMEDOUT;
	}

	out->max_x = layout_max_x;
	out->max_y = layout_max_y;
	out->panel_w = layout_panel_w;
	out->panel_h = layout_panel_h;
	out->over = layout_over;
	out->screen = layout_screen;
	out->bg_opa = layout_bg_opa;

	return 0;
}
