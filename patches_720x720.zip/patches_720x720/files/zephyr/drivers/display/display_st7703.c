/*
 * Copyright (c) 2026 Infineon Technologies AG,
 * or an affiliate of Infineon Technologies AG.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#define DT_DRV_COMPAT sitronix_st7703

#include <string.h>
#include <zephyr/device.h>
#include <zephyr/drivers/display.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>

#include "display_st7703.h"

LOG_MODULE_REGISTER(st7703, CONFIG_DISPLAY_LOG_LEVEL);

#define ST7703_DCS_MADCTL       0x36U
#define ST7703_DCS_COLMOD       0x3AU
#define ST7703_SETVCOM          0xB6U
#define ST7703_COLMOD_RGB565    0x55U
#define ST7703_COLMOD_RGB888    0x77U
#define ST7703_MAX_PARAMS       127U

struct st7703_config {
	struct gpio_dt_spec reset;
	uint16_t width;
	uint16_t height;
	uint8_t pixel_format;
	uint8_t vcom;
};

struct st7703_cmd {
	uint8_t cmd;
	uint8_t len;
	const uint8_t *data;
};

static const uint8_t cmd_b9[] = {0xF1, 0x12, 0x83};
static const uint8_t cmd_b1[] = {0x00, 0x00, 0x00, 0xDA, 0x80};
static const uint8_t cmd_b2[] = {0x3C, 0x12, 0x30};
static const uint8_t cmd_b3[] = {0x10, 0x10, 0x28, 0x28, 0x03, 0xFF, 0x00, 0x00, 0x00, 0x00};
static const uint8_t cmd_b4[] = {0x80};
static const uint8_t cmd_b5[] = {0x0A, 0x0A};
static const uint8_t cmd_b8[] = {0x26, 0x22, 0xF0, 0x13};
static const uint8_t cmd_ba[] = {
	0x31, 0x81, 0x0F, 0xF9, 0x0E, 0x06, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x44, 0x25, 0x00, 0x90, 0x0A, 0x00, 0x00, 0x01, 0x4F, 0x01, 0x00, 0x00, 0x37};
static const uint8_t cmd_bc[] = {0x47};
static const uint8_t cmd_bf[] = {0x02, 0x11, 0x00};
static const uint8_t cmd_c0[] = {0x73, 0x73, 0x50, 0x50, 0x00, 0x00, 0x12, 0x70, 0x00};
static const uint8_t cmd_c1[] = {
	0x25, 0x00, 0x32, 0x32, 0x77, 0xE4, 0xFF, 0xFF, 0xCC, 0xCC, 0x77, 0x77};
static const uint8_t cmd_c6[] = {0x82, 0x00, 0xBF, 0xFF, 0x00, 0xFF};
static const uint8_t cmd_c7[] = {0xB8, 0x00, 0x0A, 0x10, 0x01, 0x09};
static const uint8_t cmd_c8[] = {0x10, 0x40, 0x1E, 0x02};
static const uint8_t cmd_cc[] = {0x0B};
static const uint8_t cmd_e0[] = {
	0x00, 0x0B, 0x10, 0x2C, 0x3D, 0x3F, 0x42, 0x3A, 0x07, 0x0D, 0x0F, 0x13, 0x15, 0x13,
	0x14, 0x0F, 0x16, 0x00, 0x0B, 0x10, 0x2C, 0x3D, 0x3F, 0x42, 0x3A, 0x07, 0x0D, 0x0F,
	0x13, 0x15, 0x13, 0x14, 0x0F, 0x16};
static const uint8_t cmd_e3[] = {
	0x07, 0x07, 0x0B, 0x0B, 0x0B, 0x0B, 0x00, 0x00, 0x00, 0x00, 0xFF, 0x00, 0xC0, 0x10};
static const uint8_t cmd_e9[] = {
	0xC8, 0x10, 0x0A, 0x00, 0x00, 0x80, 0x81, 0x12, 0x31, 0x23, 0x4F, 0x86, 0xA0, 0x00,
	0x47, 0x08, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00,
	0x98, 0x02, 0x8B, 0xAF, 0x46, 0x02, 0x88, 0x88, 0x88, 0x88, 0x88, 0x98, 0x13, 0x8B,
	0xAF, 0x57, 0x13, 0x88, 0x88, 0x88, 0x88, 0x88, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const uint8_t cmd_ea[] = {
	0x97, 0x0C, 0x09, 0x09, 0x09, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9F, 0x31,
	0x8B, 0xA8, 0x31, 0x75, 0x88, 0x88, 0x88, 0x88, 0x88, 0x9F, 0x20, 0x8B, 0xA8, 0x20,
	0x64, 0x88, 0x88, 0x88, 0x88, 0x88, 0x23, 0x00, 0x00, 0x02, 0x71, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x80,
	0x81, 0x00, 0x00, 0x00, 0x00};
static const uint8_t cmd_ef[] = {0xFF, 0xFF, 0x01};

#define ST7703_CMD(c, d) {.cmd = (c), .len = sizeof(d), .data = (d)}

/* SETVCOM has no table entry: its value comes from devicetree. */
static const struct st7703_cmd init_sequence[] = {
	ST7703_CMD(0xB9, cmd_b9), ST7703_CMD(0xB1, cmd_b1), ST7703_CMD(0xB2, cmd_b2),
	ST7703_CMD(0xB3, cmd_b3), ST7703_CMD(0xB4, cmd_b4), ST7703_CMD(0xB5, cmd_b5),
	{.cmd = ST7703_SETVCOM, .len = 2U, .data = NULL},
	ST7703_CMD(0xB8, cmd_b8), ST7703_CMD(0xBA, cmd_ba), ST7703_CMD(0xBC, cmd_bc),
	ST7703_CMD(0xBF, cmd_bf), ST7703_CMD(0xC0, cmd_c0), ST7703_CMD(0xC1, cmd_c1),
	ST7703_CMD(0xC6, cmd_c6), ST7703_CMD(0xC7, cmd_c7), ST7703_CMD(0xC8, cmd_c8),
	ST7703_CMD(0xCC, cmd_cc), ST7703_CMD(0xE0, cmd_e0), ST7703_CMD(0xE3, cmd_e3),
	ST7703_CMD(0xE9, cmd_e9), ST7703_CMD(0xEA, cmd_ea), ST7703_CMD(0xEF, cmd_ef),
};

static int st7703_write(GFXSS_MIPIDSI_Type *base, uint8_t cmd, const uint8_t *data, uint8_t len)
{
	uint8_t packet[ST7703_MAX_PARAMS + 1U];
	cy_en_mipidsi_status_t status;

	if (len > ST7703_MAX_PARAMS) {
		return -EINVAL;
	}

	packet[0] = cmd;
	if (len > 0U) {
		memcpy(&packet[1], data, len);
	}

	status = Cy_MIPIDSI_WritePacket(base, packet, (uint32_t)len + 1U);
	if (status != CY_MIPIDSI_SUCCESS) {
		LOG_ERR("command 0x%02x failed: %d", cmd, (int)status);
		return -EIO;
	}

	return 0;
}

static void st7703_enter_command_mode(GFXSS_MIPIDSI_Type *base)
{
	base->DWCMIPIDSI.PWR_UP &= ~GFXSS_MIPIDSI_DWCMIPIDSI_PWR_UP_PWR_UP_SHUTDOWNZ_Msk;
	base->DWCMIPIDSI.MODE_CFG = GFXSS_MIPIDSI_DWCMIPIDSI_MODE_CFG_MODE_CFG_CMD_VIDEO_MODE_Msk;
	base->DWCMIPIDSI.LPCLK_CTRL =
		GFXSS_MIPIDSI_DWCMIPIDSI_LPCLK_CTRL_LPCLK_CTRL_PHY_TXREQUESTCLKHS_Msk;
	base->DWCMIPIDSI.PWR_UP |= GFXSS_MIPIDSI_DWCMIPIDSI_PWR_UP_PWR_UP_SHUTDOWNZ_Msk;

	/* CMD_MODE_CFG resets to all-HS; the panel wants its init commands in LP escape mode. */
	(void)Cy_MIPIDSI_CMD_MODE_DCS_SetLowPower(base, true);

	(void)base->DWCMIPIDSI.INT_ST0;
	(void)base->DWCMIPIDSI.INT_ST1;
}

void st7703_dsi_start_video(GFXSS_MIPIDSI_Type *base)
{
	base->DWCMIPIDSI.PWR_UP &= ~GFXSS_MIPIDSI_DWCMIPIDSI_PWR_UP_PWR_UP_SHUTDOWNZ_Msk;
	/* At 300 Mbps the link stays in HS through active lines, so the HS TX timeout
	 * would abort every few ms; keep only the LP RX timeout in the low half.
	 */
	base->DWCMIPIDSI.TO_CNT_CFG &= 0x0000FFFFUL;
	base->DWCMIPIDSI.MODE_CFG = 0U;
	base->DWCMIPIDSI.LPCLK_CTRL =
		GFXSS_MIPIDSI_DWCMIPIDSI_LPCLK_CTRL_LPCLK_CTRL_PHY_TXREQUESTCLKHS_Msk;
	base->DWCMIPIDSI.PWR_UP |= GFXSS_MIPIDSI_DWCMIPIDSI_PWR_UP_PWR_UP_SHUTDOWNZ_Msk;

	(void)base->DWCMIPIDSI.INT_ST0;
	(void)base->DWCMIPIDSI.INT_ST1;
}

int st7703_dsi_init(const struct device *dev, GFXSS_MIPIDSI_Type *base)
{
	const struct st7703_config *config = dev->config;
	const uint8_t madctl = 0x00U;
	const uint8_t colmod = (config->pixel_format == PANEL_PIXEL_FORMAT_RGB_888)
				       ? ST7703_COLMOD_RGB888
				       : ST7703_COLMOD_RGB565;
	const uint8_t setvcom[] = {config->vcom, config->vcom};
	int ret;

	st7703_enter_command_mode(base);

	ret = st7703_write(base, ST7703_DCS_MADCTL, &madctl, 1U);
	if (ret < 0) {
		return ret;
	}

	ret = st7703_write(base, ST7703_DCS_COLMOD, &colmod, 1U);
	if (ret < 0) {
		return ret;
	}

	for (size_t i = 0; i < ARRAY_SIZE(init_sequence); i++) {
		const struct st7703_cmd *c = &init_sequence[i];

		ret = st7703_write(base, c->cmd, (c->data != NULL) ? c->data : setvcom, c->len);
		if (ret < 0) {
			return ret;
		}
	}

	if (Cy_MIPIDSI_ExitSleep(base) != CY_MIPIDSI_SUCCESS) {
		LOG_ERR("sleep out failed");
		return -EIO;
	}
	k_msleep(250);

	if (Cy_MIPIDSI_DisplayON(base) != CY_MIPIDSI_SUCCESS) {
		LOG_ERR("display on failed");
		return -EIO;
	}
	k_msleep(50);

	if (config->pixel_format == PANEL_PIXEL_FORMAT_RGB_565) {
		/* The DC drives 16-bit DPI configuration 2 (vivD16CFG2); the PDL programs 1. */
		base->DWCMIPIDSI.DPI_COLOR_CODING = 1U;
	}

	LOG_DBG("ST7703 init sequence sent");

	return 0;
}

static int st7703_init(const struct device *dev)
{
	const struct st7703_config *config = dev->config;
	int ret;

	if (config->reset.port == NULL) {
		return 0;
	}

	if (!gpio_is_ready_dt(&config->reset)) {
		LOG_ERR("reset GPIO not ready");
		return -ENODEV;
	}

	ret = gpio_pin_configure_dt(&config->reset, GPIO_OUTPUT_INACTIVE);
	if (ret < 0) {
		return ret;
	}

	k_msleep(5);
	gpio_pin_set_dt(&config->reset, 1);
	k_msleep(10);
	gpio_pin_set_dt(&config->reset, 0);
	k_msleep(120);

	return 0;
}

static void st7703_get_capabilities(const struct device *dev,
				    struct display_capabilities *capabilities)
{
	const struct st7703_config *config = dev->config;

	memset(capabilities, 0, sizeof(*capabilities));
	capabilities->x_resolution = config->width;
	capabilities->y_resolution = config->height;
	capabilities->supported_pixel_formats = config->pixel_format;
	capabilities->current_pixel_format = config->pixel_format;
	capabilities->current_orientation = DISPLAY_ORIENTATION_NORMAL;
}

static DEVICE_API(display, st7703_api) = {
	.get_capabilities = st7703_get_capabilities,
};

#define ST7703_DEFINE(inst)                                                                        \
	static const struct st7703_config st7703_config_##inst = {                                 \
		.reset = GPIO_DT_SPEC_INST_GET_OR(inst, reset_gpios, {0}),                         \
		.width = DT_INST_PROP(inst, width),                                                \
		.height = DT_INST_PROP(inst, height),                                              \
		.pixel_format = DT_INST_PROP(inst, pixel_format),                                  \
		.vcom = DT_INST_PROP(inst, vcom),                                                  \
	};                                                                                         \
	DEVICE_DT_INST_DEFINE(inst, st7703_init, NULL, NULL, &st7703_config_##inst, POST_KERNEL,   \
			      CONFIG_DISPLAY_INIT_PRIORITY, &st7703_api);

DT_INST_FOREACH_STATUS_OKAY(ST7703_DEFINE)
