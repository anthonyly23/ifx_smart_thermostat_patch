#
# SPDX-License-Identifier: Apache-2.0
#

cmake_minimum_required(VERSION 3.20.0)

# The H.264 decoder is vendored here rather than fetched as a west project.
# It could now be a project in west.yml - this repository is the manifest
# repository, so a module under modules/ would be pinned with everything else -
# but it is a small, frozen, decade-old import that we patch for our allocator,
# and keeping it in-tree means the thing being built is the thing being read.
list(APPEND ZEPHYR_EXTRA_MODULES ${CMAKE_CURRENT_SOURCE_DIR}/third_party/h264bsd)

# Display panel on the PSOC Edge kit, chosen at configure time:
#   west build ... -- -DLCD_PANEL=LCD_800_480
#   LCD_720_720  ST7703 720x720 + GT911 touch (default)
#   LCD_800_480  Waveshare 4.3" 800x480 + FT5336 touch
# The name is defined for the board overlay and for the application sources.
set(LCD_PANEL LCD_720_720 CACHE STRING "Display panel: LCD_720_720 or LCD_800_480")
set_property(CACHE LCD_PANEL PROPERTY STRINGS LCD_720_720 LCD_800_480)
set(lcd_panel_board ${BOARD})
# Under sysbuild, image settings and BOARD are only loaded inside find_package(Zephyr),
# which is too late for devicetree, so read them from the sysbuild cache here.
if(DEFINED SYSBUILD_CACHE AND EXISTS "${SYSBUILD_CACHE}")
  file(STRINGS "${SYSBUILD_CACHE}" sb_lines REGEX "^(BOARD|(ifx_smart_thermostat_)?LCD_PANEL):")
  foreach(sb_line IN LISTS sb_lines)
    if(sb_line MATCHES "^BOARD:[A-Z]+=(.*)$")
      set(lcd_panel_board ${CMAKE_MATCH_1})
    elseif(sb_line MATCHES "^LCD_PANEL:[A-Z]+=(.*)$" AND NOT sb_lcd_panel_local)
      set(LCD_PANEL ${CMAKE_MATCH_1})
    elseif(sb_line MATCHES "^ifx_smart_thermostat_LCD_PANEL:[A-Z]+=(.*)$")
      set(LCD_PANEL ${CMAKE_MATCH_1})
      set(sb_lcd_panel_local TRUE)
    endif()
  endforeach()
endif()
if(NOT LCD_PANEL MATCHES "^LCD_(720_720|800_480)$")
  message(FATAL_ERROR "LCD_PANEL must be LCD_720_720 or LCD_800_480, not '${LCD_PANEL}'")
endif()
message(STATUS "Display panel: ${LCD_PANEL}")
list(APPEND DTS_EXTRA_CPPFLAGS -D${LCD_PANEL})
if(lcd_panel_board MATCHES "^kit_pse84_eval")
  string(TOLOWER ${LCD_PANEL} lcd_panel_conf)
  list(APPEND EXTRA_CONF_FILE ${CMAKE_CURRENT_SOURCE_DIR}/${lcd_panel_conf}.conf)
endif()

find_package(Zephyr REQUIRED HINTS $ENV{ZEPHYR_BASE})
project(ifx_smart_thermostat)

target_compile_definitions(app PRIVATE ${LCD_PANEL})

target_sources(app PRIVATE
  src/main.c
  src/control.c
  src/crc32.c
  src/fault.c
  src/ui.c
  src/logo.c
  src/dphy_ref_clk.c
)

target_sources_ifdef(CONFIG_DOORBELL_FAST_MEM app PRIVATE src/mem_fast.c)

# Only built when the NPU is enabled, which is a measurement build rather than
# a shipping one.
target_sources_ifdef(CONFIG_ETHOS_U app PRIVATE src/npu_bench.c)

# -fno-builtin so the compiler cannot turn the loops in mem_fast.c into calls
# to the very functions they implement, and -fno-tree-loop-distribute-patterns
# so it cannot recognise a byte tail as a memset and call one. Both would be
# infinite recursion rather than a slow path.
if(CONFIG_DOORBELL_FAST_MEM)
  set_source_files_properties(src/mem_fast.c
    PROPERTIES COMPILE_OPTIONS "-fno-builtin;-fno-tree-loop-distribute-patterns")
endif()

# Console commands for driving a call without the touch panel, which is what
# makes scripted end-to-end tests possible.
target_sources_ifdef(CONFIG_SHELL app PRIVATE src/shell.c src/kbench.c)

# Tracing reaches into the subsystem's own headers for the backend record,
# which is how tracing_core.c finds it too. Nothing here modifies Zephyr; the
# include path is app-side.
target_sources_ifdef(CONFIG_DOORBELL_TRACING app PRIVATE src/trace.c)
if(CONFIG_DOORBELL_TRACING)
  target_include_directories(app PRIVATE
    ${ZEPHYR_BASE}/subsys/tracing/include
    ${ZEPHYR_BASE}/subsys/tracing/ctf)
endif()

# Audio needs the I2S/codec hardware, which native_sim does not model.
target_sources_ifdef(CONFIG_I2S app PRIVATE src/audio.c src/rtp.c
	src/video.c
	src/rtsp.c
	src/decode.c)

# Talkback capture from the PDM microphone pair.
target_sources_ifdef(CONFIG_AUDIO_DMIC app PRIVATE src/mic.c)

# Smoke-detector alarm detection on the PDM microphone stream. The DEEPCRAFT
# inference library is a frozen, pre-built GCC_ARM archive vendored under
# third_party/deepcraft rather than a west project - there is no source to
# build and nothing to pin but the blob itself. Its model weights link into
# .cy_socmem_data, which the SoC's rwdata.ld places in the main .data region
# (in SOCMEM); Zephyr's startup copy fills it from flash like any other .data.
if(CONFIG_FIRE_ALARM_DETECT)
  target_sources(app PRIVATE src/alarm.c)
  target_include_directories(app PRIVATE third_party/deepcraft)
  target_link_libraries(app PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/deepcraft/lib/alarm_siren_lib_eval.a)
endif()

# native_sim builds use host networking directly and have no Wi-Fi driver.
target_sources_ifdef(CONFIG_WIFI app PRIVATE src/wifi.c)

target_include_directories(app PRIVATE src)

option(RELOCATE_KERNEL_TO_ITCM
  "Place the kernel, timer, serial and context-switch code in ITCM. Measured
   slower than leaving it in cached flash - see the comment below." OFF)

option(RELOCATE_WIFI_TO_ITCM
  "Place the AIROC driver, the SDIO host and WHD (but not its firmware blob)
   in ITCM. Measured 37% cheaper per packet - see the comment below." ON)

# The M55 has 256 KB of DTCM that nothing was using. It is zero-wait-state and
# it is not SOCMEM, so every byte of application state moved there is a byte of
# SOCMEM released to frame buffers, and the hot paths get faster in the bargain.
#
# What must NOT move: DTCM is tightly coupled to the core, so no DMA master can
# reach it. audio.c owns the I2S playback slab and mic.c owns the PDM capture
# slab, and both are handed straight to a driver as DMA targets, so those two
# files stay in SOCMEM. Everything the drivers own stays there too, because
# zephyr,sram is still m55_data - relocation is opt-in, so a DMA buffer we
# failed to think of stays safe by default rather than breaking quietly.
#
# Guarded on the SoC series rather than on the core. Everything below is an
# argument about *this* part - SOCMEM, the m55_data/gfx_mem split, which masters
# can reach which memory, and a cache result measured on this silicon - and none
# of it carries to the other Cortex-M55 parts Zephyr supports, which have their
# own memory maps and in some cases no TCM regions by these names at all. On
# anything else the application still builds and runs; it just keeps its data
# wherever zephyr,sram puts it, which is the correct default.
# The cacheable video region, described in the board overlay, needs a section
# to put things in. An application can add linker fragments the same way a SoC
# can, so this does not have to live in Zephyr.
if(CONFIG_SOC_SERIES_PSE84_M55)
  zephyr_linker_sources(SECTIONS linker/video_mem.ld)
endif()

if(CONFIG_CODE_DATA_RELOCATION AND CONFIG_SOC_SERIES_PSE84_M55)
  zephyr_code_relocate(FILES src/main.c src/control.c src/ui.c src/logo.c
    LOCATION DTCM_BSS)
  zephyr_code_relocate(FILES src/main.c src/control.c src/ui.c src/logo.c
    LOCATION DTCM_NOINIT)
  if(CONFIG_SHELL)
    zephyr_code_relocate(FILES src/shell.c LOCATION DTCM_BSS)
    zephyr_code_relocate(FILES src/shell.c LOCATION DTCM_NOINIT)
  endif()
  if(CONFIG_WIFI)
    zephyr_code_relocate(FILES src/wifi.c LOCATION DTCM_BSS)
    zephyr_code_relocate(FILES src/wifi.c LOCATION DTCM_NOINIT)
  endif()

  # A useful trace is tens of kilobytes and SOCMEM has nothing like that
  # spare, while DTCM is barely a tenth used. The buffer is only ever written
  # by the tracing thread and read by the shell, so the tight coupling is no
  # loss - and putting it here is what makes a capture long enough to be worth
  # converting. The file is named, not modified.
  if(CONFIG_DOORBELL_TRACING)
    zephyr_code_relocate(FILES ${ZEPHYR_BASE}/subsys/tracing/tracing_backend_ram.c
      LOCATION DTCM_BSS)
  endif()

  # The decoder lives in ITCM (see H264BSD_ITCM) and it was worth asking
  # whether the code underneath it should too - the kernel, the interrupt and
  # context-switch paths, the system timer and the console UART are hit
  # constantly by every thread, and this runs execute-in-place from external
  # octal-SPI flash where an instruction miss is a flash transaction.
  #
  # It was tried, and it is slower. Measured with "kbench" on the two builds,
  # nanoseconds per operation, three runs each and repeatable to the
  # nanosecond on the uncontended cases:
  #
  #                      in flash   in ITCM
  #     sem give/take         385       411   +6.8%
  #     mutex lock/unlock     320       343   +7.2%
  #     k_uptime_ticks        531       564   +6.2%
  #     k_yield               653       668   +2.3%
  #
  # The reason is that the M55's instruction cache was already doing this job.
  # This code is small and runs constantly, so it stays resident and is served
  # in about a cycle; ITCM is *not* behind the cache, so moving it there
  # replaces a cache hit with a TCM access on every single fetch. Tightly
  # coupled memory wins for code whose footprint is too large to stay cached -
  # which is why it does pay for the decoder - and loses for hot code that was
  # never missing in the first place.
  #
  # Left switchable rather than deleted, so the next person to have this idea
  # can re-run kbench instead of re-deriving it. Default off, because off is
  # the faster setting.
  #
  # If it is ever turned on, note what must stay in flash: anything reached
  # before the copy that fills ITCM. That copy is called from arch_data_copy()
  # in cortex_m/prep_c.c, so prep_c.c, reset.S, vector_table.S and fpu.c are
  # all excluded, as is arch__common, which holds the arch_early_memcpy() doing
  # the copying. Relocating any of them would branch into ITCM before anything
  # had been put there. fault.c, fault_s.S and scb.c stay in flash on purpose
  # too: a fault handler living in memory that may itself be the problem is no
  # use for working out what went wrong.
  #
  # src/kbench.c, which measures all this, is deliberately left in flash by
  # both lists - it is the ruler, and a ruler that changes length between
  # measurements is no use.
  if(RELOCATE_KERNEL_TO_ITCM)
    zephyr_code_relocate(LIBRARY kernel LOCATION ITCM_TEXT)
    zephyr_code_relocate(LIBRARY drivers__timer LOCATION ITCM_TEXT)
    zephyr_code_relocate(LIBRARY drivers__serial LOCATION ITCM_TEXT)

    set(CORTEX_M ${ZEPHYR_BASE}/arch/arm/core/cortex_m)
    zephyr_code_relocate(FILES
      ${CORTEX_M}/isr_wrapper.c
      ${CORTEX_M}/exc_exit.c
      ${CORTEX_M}/irq_manage.c
      ${CORTEX_M}/cpu_idle.c
      ${CORTEX_M}/thread.c
      ${CORTEX_M}/swap_helper.S
      LOCATION ITCM_TEXT)
  endif()

  # The Wi-Fi path is the one case where the cache argument runs the other way.
  # "kbench" reports the instruction cache as 32 KB and only *two-way* set
  # associative, and the per-packet path - the AIROC driver, the SDIO host and
  # the WHD bus/SDPCM/CDC-BDC layers - is around 37 KB of text on its own,
  # before lwIP, LVGL and the UI ask for any of the same cache. Two ways means
  # two hot functions landing in the same set evict each other even well under
  # capacity. Unlike the kernel, whose hot path is a few KB and stays resident,
  # this one plausibly thrashes, and thrashing code is exactly what ITCM is for.
  #
  # It does. Measured with "bench_call.py --workload video", which divides each
  # thread's cycles by the packets the board actually received, so that the
  # radio dropping a different number of packets each run (D20) does not spoil
  # the reading:
  #
  #     WHD thread   43.09 cycles/packet in flash
  #                  27.21 cycles/packet in ITCM     -36.9%
  #
  # with a run-to-run spread of 5.1% and 4.3%, so the difference is real. Note
  # that this is the reverse of the kernel result above, and for the reason the
  # cache geometry predicts, not despite it.
  #
  # Only the WHD thread is claimed. rx_q barely moves (11.13 to 10.78), and
  # total busy cycles are not quoted because the two threads that dominate them,
  # doorbell_ui and dbp_decode, do work proportional to pictures and bits rather
  # than to packets - dividing them by packets produces a number that mostly
  # reports what the encoder chose to send.
  #
  # The firmware blob is the thing to keep out: whd_resources.c is 315 KB of
  # data and would not fit in the 256 KB of ITCM even on its own. It lives in
  # resources/resource_imp rather than src, so globbing the source directories
  # leaves it behind without needing to name it.
  #
  # The WHD variant is chosen by CONFIG_AIROC_WIFI6 in the HAL's own
  # CMakeLists, and that choice is mirrored rather than assumed, so this
  # follows the module if the board ever switches.
  if(RELOCATE_WIFI_TO_ITCM AND CONFIG_WIFI_AIROC)
    if(CONFIG_AIROC_WIFI6)
      set(WHD_VER COMPONENT_WIFI6)
    else()
      set(WHD_VER COMPONENT_WIFI5)
    endif()
    set(WHD_DIR ${ZEPHYR_HAL_INFINEON_MODULE_DIR}/whd-expansion/WHD)

    file(GLOB WHD_SOURCES
      ${WHD_DIR}/COMMON/src/*.c
      ${WHD_DIR}/${WHD_VER}/src/*.c
      ${WHD_DIR}/${WHD_VER}/src/bus_protocols/*.c)

    if(NOT WHD_SOURCES)
      message(FATAL_ERROR
        "RELOCATE_WIFI_TO_ITCM is on but no WHD sources were found under "
        "${WHD_DIR}. The host driver has moved; fix the glob rather than "
        "silently relocating nothing.")
    endif()

    zephyr_code_relocate(FILES ${WHD_SOURCES} LOCATION ITCM_TEXT)
    zephyr_code_relocate(LIBRARY drivers__wifi LOCATION ITCM_TEXT)
    zephyr_code_relocate(LIBRARY drivers__sdhc LOCATION ITCM_TEXT)
    zephyr_code_relocate(FILES
      ${ZEPHYR_HAL_INFINEON_MODULE_DIR}/mtb-dsl-pse8xxgp/pdl/drivers/source/cy_sd_host.c
      LOCATION ITCM_TEXT)
  endif()
endif()
