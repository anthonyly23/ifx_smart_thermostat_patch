/*
 * Copyright (c) 2026 Infineon Technologies AG,
 * or an affiliate of Infineon Technologies AG.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef DOORBELL_AUDIO_H_
#define DOORBELL_AUDIO_H_

#include <stddef.h>
#include <stdint.h>

/* Narrowband telephony rate; G.711 carries 8 kHz mono over the wire. */
#define DOORBELL_AUDIO_RATE_HZ 8000

/* Samples of mono audio carried in one frame (20 ms, the RTP packetisation). */
#define DOORBELL_AUDIO_FRAME_SAMPLES (DOORBELL_AUDIO_RATE_HZ / 50)

/**
 * Bring up the I2S transmitter and the TLV320DAC3100. Safe to call once at
 * boot; the codec is left configured but muted until playback starts.
 */
int doorbell_audio_init(void);

/** Unmute the speaker and start the I2S transmit stream. */
int doorbell_audio_start(void);

/** Stop the transmit stream and mute the speaker. */
int doorbell_audio_stop(void);

/**
 * Queue one mono frame for playback. Samples are duplicated to both I2S
 * channels. Returns -EAGAIN if the transmit queue is full so callers can drop
 * rather than block the network path.
 */
int doorbell_audio_play(const int16_t *samples, size_t count);

/** Play a short tone through the speaker; used to validate the audio path. */
int doorbell_audio_test_tone(void);

/** Play the two-tone doorbell chime. Blocks for roughly a second. */
int doorbell_audio_ring_tone(void);

/** Playback buffers in the transmit slab, which doubles as the jitter buffer. */
#define DOORBELL_AUDIO_BLOCK_COUNT 12

/**
 * @brief Number of playback buffers currently free.
 *
 * The transmit slab is also the jitter buffer, so this is the headroom the
 * call has left. It should return to its full count between calls; anything
 * less means blocks are not finding their way back.
 */
uint32_t doorbell_audio_free_blocks(void);

#endif /* DOORBELL_AUDIO_H_ */
