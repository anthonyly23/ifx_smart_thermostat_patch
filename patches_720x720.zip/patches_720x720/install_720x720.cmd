@echo off
rem Runs install_720x720.ps1 without changing the machine's PowerShell execution policy.
rem   install_720x720.cmd                        -> C:\workspace_eco
rem   install_720x720.cmd C:\other_ws            -> another workspace
rem   install_720x720.cmd C:\workspace_eco -DryRun
if "%~1"=="" (
	powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_720x720.ps1"
) else (
	powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_720x720.ps1" -Workspace "%~1" %2
)
