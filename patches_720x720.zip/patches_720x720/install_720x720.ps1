# Installs the 720x720 ST7703 display + GT911 touch support by copying .\files over a workspace.
# Every file it replaces is saved first to .\backup_<time>\, so the install can be undone.
#   .\install_720x720.ps1                         # C:\workspace_eco
#   .\install_720x720.ps1 -Workspace D:\other_ws  # another west workspace
#   .\install_720x720.ps1 -DryRun                 # list what would be copied
param(
	[string]$Workspace = 'C:\workspace_eco',
	[switch]$DryRun
)

$ErrorActionPreference = 'Stop'

$src = Join-Path $PSScriptRoot 'files'
$backup = Join-Path $PSScriptRoot ('backup_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))

foreach ($dir in 'zephyr', 'ifx_smart_thermostat') {
	if (-not (Test-Path (Join-Path $Workspace $dir))) { throw "missing $(Join-Path $Workspace $dir)" }
}

$files = Get-ChildItem -Path $src -Recurse -File
foreach ($file in $files) {
	$rel = $file.FullName.Substring($src.Length + 1)
	$to = Join-Path $Workspace $rel

	if ($DryRun) {
		Write-Host ("{0} {1}" -f ($(if (Test-Path -LiteralPath $to) { 'replace' } else { 'add    ' })), $rel)
		continue
	}

	if (Test-Path -LiteralPath $to) {
		$saved = Join-Path $backup $rel
		New-Item -ItemType Directory -Force -Path (Split-Path $saved) | Out-Null
		Copy-Item -LiteralPath $to -Destination $saved
	}
	New-Item -ItemType Directory -Force -Path (Split-Path $to) | Out-Null
	Copy-Item -LiteralPath $file.FullName -Destination $to -Force
	Write-Host "copied $rel"
}

if (-not $DryRun) {
	Write-Host "$($files.Count) files installed into $Workspace"
	if (Test-Path $backup) { Write-Host "previous versions saved in $backup" }
	Write-Host "Build with:"
	Write-Host "  west build -p always -b kit_pse84_eval/pse846gps2dbzc4a/m55 ifx_smart_thermostat --sysbuild"
}
