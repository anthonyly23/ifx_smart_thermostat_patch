/*
 * Copyright (c) 2026 Infineon Technologies AG,
 * or an affiliate of Infineon Technologies AG.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "audio.h"

#include <zephyr/audio/codec.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2s.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(doorbell_audio, LOG_LEVEL_INF);

/*
 * The codec's MCLK is the peripheral clock feeding the I2S block. The overlay
 * divides clk_hf7 (49.152 MHz) by 4, so this must stay in step with
 * peri1_group1_16_5bit_0 in the board overlay.
 */
#define AUDIO_MCLK_HZ 12288000

#define AUDIO_WORD_SIZE  16
#define AUDIO_CHANNELS   2

/* Stereo 16-bit frame expanded from one mono frame. */
#define BLOCK_BYTES (DOORBELL_AUDIO_FRAME_SAMPLES * AUDIO_CHANNELS * sizeof(int16_t))

/*
 * Enough blocks to absorb network jitter without letting the I2S transmitter
 * underrun, but small enough that the added latency stays well under the
 * plan's budget (12 x 20 ms = 240 ms worst case, typically 4-5 queued).
 */
#define BLOCK_COUNT DOORBELL_AUDIO_BLOCK_COUNT

/*
 * Blocks of silence queued before the transmitter is started. One is the bare
 * minimum the driver needs, but the sender's 20 ms pacing and our 8 kHz drain
 * rate are driven by unrelated clocks, so a single block underruns on the
 * first scheduling hiccup. Five gives a 100 ms cushion, enough to ride out the
 * Wi-Fi loss bursts seen during video calls.
 */
#define PRIME_BLOCKS 5

K_MEM_SLAB_DEFINE_STATIC(tx_slab, BLOCK_BYTES, BLOCK_COUNT, 4);

static const struct device *const i2s_dev = DEVICE_DT_GET(DT_NODELABEL(i2s0));
static const struct device *const codec_dev = DEVICE_DT_GET(DT_NODELABEL(audio_codec));

static bool running;

/*
 * Set while a call owns the speaker. Tones share the same I2S stream, so
 * without this a chime finishing just after the user hits Answer would stop
 * the stream out from under the call.
 */
static bool call_active;

/* Rate limit for the underrun warning, which would otherwise repeat at 50 Hz. */
static int64_t last_underrun_log;

/*
 * Saved so every call start can rebuild the transmitter from the same state the
 * first call gets from doorbell_audio_init(). Stopping a call only DROPs the
 * stream, which tears down the TDM and its DMA without re-initialising them, so
 * a plain START on the next call would run into silence.
 */
static struct i2s_config i2s_cfg;

static int queue_block(const int16_t *samples, size_t count);
static int audio_engine_start(void);
static int audio_engine_stop(void);
static int drain_tx(void);
static int recover_tx(void);

int doorbell_audio_init(void)
{
	struct audio_codec_cfg codec_cfg;
	int ret;

	if (!device_is_ready(i2s_dev)) {
		LOG_ERR("i2s0 not ready");
		return -ENODEV;
	}

	if (!device_is_ready(codec_dev)) {
		LOG_ERR("audio codec not ready");
		return -ENODEV;
	}

	i2s_cfg.word_size = AUDIO_WORD_SIZE;
	i2s_cfg.channels = AUDIO_CHANNELS;
	i2s_cfg.format = I2S_FMT_DATA_FORMAT_I2S;
	/* The TDM block is the bit and frame clock controller; the codec follows. */
	i2s_cfg.options = I2S_OPT_FRAME_CLK_CONTROLLER | I2S_OPT_BIT_CLK_CONTROLLER;
	i2s_cfg.frame_clk_freq = DOORBELL_AUDIO_RATE_HZ;
	i2s_cfg.block_size = BLOCK_BYTES;
	i2s_cfg.mem_slab = &tx_slab;
	/* Underruns should not kill the stream: keep transmitting silence. */
	i2s_cfg.timeout = 0;

	ret = i2s_configure(i2s_dev, I2S_DIR_TX, &i2s_cfg);
	if (ret < 0) {
		LOG_ERR("i2s_configure failed (%d)", ret);
		return ret;
	}

	codec_cfg.dai_type = AUDIO_DAI_TYPE_I2S;
	codec_cfg.dai_route = AUDIO_ROUTE_PLAYBACK;
	codec_cfg.mclk_freq = AUDIO_MCLK_HZ;
	codec_cfg.dai_cfg.i2s = i2s_cfg;
	/* The codec is the clock target, so clear the controller options. */
	codec_cfg.dai_cfg.i2s.options = I2S_OPT_FRAME_CLK_TARGET | I2S_OPT_BIT_CLK_TARGET;

	ret = audio_codec_configure(codec_dev, &codec_cfg);
	if (ret < 0) {
		LOG_ERR("audio_codec_configure failed (%d)", ret);
		return ret;
	}

	LOG_INF("audio ready: %d Hz, MCLK %d Hz", DOORBELL_AUDIO_RATE_HZ, AUDIO_MCLK_HZ);
	return 0;
}

static int audio_engine_start(void)
{
	int ret;

	if (running) {
		return 0;
	}

	/*
	 * Rebuild the transmitter from scratch. After a call, DROP leaves the
	 * TDM and its DMA in a state a plain START does not revive, so the
	 * second call would otherwise START into silence. Reconfiguring runs a
	 * fresh Cy_AudioTDM_Init(), matching the first call's known-good start.
	 */
	ret = i2s_configure(i2s_dev, I2S_DIR_TX, &i2s_cfg);
	if (ret < 0) {
		LOG_ERR("i2s reconfigure failed (%d)", ret);
		return ret;
	}

	/*
	 * Prime the transmitter before START. The driver needs at least one
	 * queued block or it reports an underrun straight away, and a few more
	 * buy tolerance for jitter once real audio arrives.
	 */
	for (int i = 0; i < PRIME_BLOCKS; i++) {
		ret = queue_block(NULL, DOORBELL_AUDIO_FRAME_SAMPLES);
		if (ret < 0) {
			return ret;
		}
	}

	ret = i2s_trigger(i2s_dev, I2S_DIR_TX, I2S_TRIGGER_START);
	if (ret < 0) {
		LOG_ERR("i2s start failed (%d)", ret);
		return ret;
	}

	audio_codec_start_output(codec_dev);
	running = true;
	return 0;
}

static int audio_engine_stop(void)
{
	if (!running) {
		return 0;
	}

	running = false;
	audio_codec_stop_output(codec_dev);

	/* DROP rather than DRAIN so hang-up is immediate. */
	(void)i2s_trigger(i2s_dev, I2S_DIR_TX, I2S_TRIGGER_DROP);
	return 0;
}

int doorbell_audio_start(void)
{
	call_active = true;
	return audio_engine_start();
}

int doorbell_audio_stop(void)
{
	call_active = false;
	return audio_engine_stop();
}

uint32_t doorbell_audio_free_blocks(void)
{
	return k_mem_slab_num_free_get(&tx_slab);
}

static int queue_block(const int16_t *samples, size_t count)
{
	int16_t *block;
	int ret;

	if (count > DOORBELL_AUDIO_FRAME_SAMPLES) {
		count = DOORBELL_AUDIO_FRAME_SAMPLES;
	}

	ret = k_mem_slab_alloc(&tx_slab, (void **)&block, K_NO_WAIT);
	if (ret < 0) {
		/* Playback is behind; drop this frame instead of blocking. */
		return -EAGAIN;
	}

	memset(block, 0, BLOCK_BYTES);
	if (samples != NULL) {
		for (size_t i = 0; i < count; i++) {
			/* Mono source, duplicated across both I2S channels. */
			block[i * AUDIO_CHANNELS] = samples[i];
			block[i * AUDIO_CHANNELS + 1] = samples[i];
		}
	}

	ret = i2s_write(i2s_dev, block, BLOCK_BYTES);
	if (ret < 0) {
		k_mem_slab_free(&tx_slab, block);
		return ret;
	}

	return 0;
}

/* Reclaim every block the transmitter is holding. DROP is what returns queued
 * buffers to the slab, so this is the only way back from a slab that has been
 * emptied into a transmitter which is no longer draining it. DROP also leaves
 * the stream in READY.
 */
static int drain_tx(void)
{
	int ret = i2s_trigger(i2s_dev, I2S_DIR_TX, I2S_TRIGGER_DROP);

	if (ret < 0) {
		LOG_ERR("i2s drop failed (%d)", ret);
		return ret;
	}

	if (k_mem_slab_num_free_get(&tx_slab) == 0) {
		LOG_ERR("transmitter still holds every playback buffer");
		return -EIO;
	}

	return 0;
}

/* Re-prime with silence and start the transmitter. Valid from READY, which is
 * where both DROP and PREPARE leave the stream.
 */
static int prime_and_start_tx(void)
{
	int ret;

	for (int i = 0; i < PRIME_BLOCKS; i++) {
		ret = queue_block(NULL, DOORBELL_AUDIO_FRAME_SAMPLES);
		if (ret < 0) {
			return ret;
		}
	}

	return i2s_trigger(i2s_dev, I2S_DIR_TX, I2S_TRIGGER_START);
}

/*
 * An underrun leaves the transmitter latched in the error state, and every
 * subsequent i2s_write() returns -EIO, so a momentary stall would otherwise
 * kill audio for the rest of the call. PREPARE is the only way back to READY
 * from the error state (and is rejected from any other state); re-prime and
 * restart from there.
 */
static int recover_tx(void)
{
	int ret = i2s_trigger(i2s_dev, I2S_DIR_TX, I2S_TRIGGER_PREPARE);

	if (ret < 0) {
		LOG_ERR("i2s prepare failed (%d)", ret);
		return ret;
	}

	return prime_and_start_tx();
}

/*
 * A transmitter that has stopped consuming is indistinguishable from one that
 * is merely behind: both show up as an empty slab. The difference is that
 * being behind is transient. Once a whole buffer's worth of frames in a row
 * have found nowhere to go, the audio the slab is holding is already older
 * than the buffer is deep, so there is nothing left to protect by waiting.
 *
 * This was seen in the field as a call in which every single packet arrived
 * intact and every single one was dropped, with no error anywhere to explain
 * it, and it lasted until the board was reset.
 */
#define STALL_FRAMES DOORBELL_AUDIO_BLOCK_COUNT

int doorbell_audio_play(const int16_t *samples, size_t count)
{
	static unsigned int starved;
	int ret = queue_block(samples, count);

	if (ret == -EAGAIN) {
		if (++starved < STALL_FRAMES) {
			return ret;
		}

		LOG_WRN("no playback buffer for %u frames, restarting the transmitter",
			starved);
		starved = 0;

		/* DROP has already returned the stream to READY, so restart from
		 * there. Issuing PREPARE here would be rejected (-EIO) because it is
		 * only valid out of the error state, wedging the transmitter.
		 */
		if (drain_tx() < 0 || prime_and_start_tx() < 0) {
			return ret;
		}

		return queue_block(samples, count);
	}

	starved = 0;

	if (ret != -EIO) {
		return ret;
	}

	/* Recover once and retry, so a stall costs a frame rather than the call.
	 * Logged sparsely because an underrun otherwise repeats every 20 ms.
	 */
	if (k_uptime_get() - last_underrun_log > 1000) {
		last_underrun_log = k_uptime_get();
		LOG_WRN("i2s underrun, restarting the transmitter");
	}

	ret = recover_tx();
	if (ret < 0) {
		return ret;
	}

	return queue_block(samples, count);
}

/*
 * Plays `frames` 20 ms frames of a square-ish tone. `period` is the number of
 * samples per cycle, so 8 gives 1 kHz and 12 gives ~667 Hz at 8 kHz sampling.
 */
static int play_tone(unsigned int period, unsigned int frames, int16_t amplitude,
		     bool owner)
{
	int16_t frame[DOORBELL_AUDIO_FRAME_SAMPLES];
	unsigned int phase = 0;

	for (unsigned int f = 0; f < frames; f++) {
		/* Answering cuts the chime off mid-note, which is both what a
		 * caller expects and what leaves the playback queue free for
		 * the conversation that is already arriving.
		 */
		if (call_active != owner) {
			return 0;
		}

		for (size_t i = 0; i < ARRAY_SIZE(frame); i++) {
			frame[i] = (phase % period) < (period / 2) ? amplitude : -amplitude;
			phase++;
		}

		for (int attempt = 0; attempt < 20; attempt++) {
			int ret = doorbell_audio_play(frame, ARRAY_SIZE(frame));

			if (ret == -EAGAIN) {
				/* Queue full: let the transmitter drain. */
				k_sleep(K_MSEC(5));
				continue;
			}
			if (ret < 0) {
				LOG_ERR("tone play failed (%d)", ret);
				return ret;
			}
			break;
		}
	}

	return 0;
}

/*
 * Feeds silence so the transmitter never sits idle, which would underrun and
 * latch the stream in an error state.
 *
 * `owner` is the value of call_active when the tone started. If that changes
 * the stream has been handed to or taken from a call, and this silence is no
 * longer wanted: every block it queues is a block the call's incoming audio
 * cannot allocate, and the trailing second of a chime was enough to starve the
 * first second of a conversation.
 */
static int play_silence(unsigned int frames, bool owner)
{
	for (unsigned int f = 0; f < frames; f++) {
		if (call_active != owner) {
			return 0;
		}

		for (int attempt = 0; attempt < 20; attempt++) {
			int ret = doorbell_audio_play(NULL, DOORBELL_AUDIO_FRAME_SAMPLES);

			if (ret == -EAGAIN) {
				k_sleep(K_MSEC(5));
				continue;
			}
			if (ret < 0) {
				return ret;
			}
			break;
		}
	}

	return 0;
}

int doorbell_audio_test_tone(void)
{
	bool owner = call_active;
	int ret = audio_engine_start();

	if (ret < 0) {
		return ret;
	}

	/* 400 ms of 1 kHz. */
	ret = play_tone(8, 20, 9000, owner);

	play_silence(25, owner);
	if (!call_active) {
		audio_engine_stop();
	}
	return ret;
}

static int ring_tone_blocking(void)
{
	bool owner = call_active;
	int ret = audio_engine_start();

	if (ret < 0) {
		return ret;
	}

	/* Two-tone "ding-dong": ~1 kHz then ~667 Hz. */
	ret = play_tone(8, 15, 9000, owner);
	if (ret == 0) {
		ret = play_silence(3, owner);
	}
	if (ret == 0) {
		ret = play_tone(12, 25, 9000, owner);
	}

	/* Hold the stream open a moment in case the call is about to take it,
	 * so the handover does not pass through an underrun.
	 */
	play_silence(50, owner);

	/* The user may have answered while the chime was playing; in that case
	 * the call now owns the stream and must not be cut off.
	 */
	if (!call_active) {
		audio_engine_stop();
	}
	return ret;
}

/*
 * The chime lasts about a second, and on_ring() runs on the control server
 * thread which still has a ring_ack to send, so play it on a dedicated thread.
 * A binary semaphore means a burst of rings collapses into one chime.
 */
static K_SEM_DEFINE(ring_request, 0, 1);

static void ring_thread_fn(void *a, void *b, void *c)
{
	ARG_UNUSED(a);
	ARG_UNUSED(b);
	ARG_UNUSED(c);

	while (true) {
		k_sem_take(&ring_request, K_FOREVER);
		ring_tone_blocking();
	}
}

K_THREAD_DEFINE(doorbell_ring_tone, 1536, ring_thread_fn, NULL, NULL, NULL, 7, 0, 0);

int doorbell_audio_ring_tone(void)
{
	k_sem_give(&ring_request);
	return 0;
}
