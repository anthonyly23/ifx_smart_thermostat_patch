/*
 * MIPI D-PHY PLL reference: CLK_HF12 <- clock path 4 <- 24 MHz EXT_CLK on P7.4, as in the
 * working ModusToolbox design. The Zephyr board feeds path 4 from the 50 MHz IHO instead,
 * and the PDL's 300 Mbps PLL settings assume a 24 MHz reference.
 */

#include <zephyr/devicetree.h>
#include <zephyr/init.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>

#include "cy_gpio.h"
#include "cy_sysclk.h"

LOG_MODULE_REGISTER(dphy_ref_clk, LOG_LEVEL_INF);

#define DPHY_REF_CLK_HZ   24000000UL
#define DPHY_REF_CLK_PATH 4U
#define DPHY_REF_CLK_HF   12U

static int dphy_ref_clk_init(void)
{
	cy_en_sysclk_status_t st;

	Cy_GPIO_Pin_FastInit(GPIO_PRT7, 4U, CY_GPIO_DM_HIGHZ, 0U, P7_4_SRSS_EXT_CLK);
	Cy_SysClk_ExtClkSetFrequency(DPHY_REF_CLK_HZ);

	st = Cy_SysClk_ClkPathSetSource(DPHY_REF_CLK_PATH, CY_SYSCLK_CLKPATH_IN_EXT);
	if (st == CY_SYSCLK_SUCCESS) {
		st = Cy_SysClk_ClkHfSetSource(DPHY_REF_CLK_HF, CY_SYSCLK_CLKHF_IN_CLKPATH4);
	}
	if (st == CY_SYSCLK_SUCCESS) {
		st = Cy_SysClk_ClkHfSetDivider(DPHY_REF_CLK_HF, CY_SYSCLK_CLKHF_NO_DIVIDE);
	}
	if (st == CY_SYSCLK_SUCCESS) {
		st = Cy_SysClk_ClkHfEnable(DPHY_REF_CLK_HF);
	}

	LOG_INF("D-PHY ref: CLK_HF12 = %u Hz (status 0x%x)",
		(unsigned int)Cy_SysClk_ClkHfGetFrequency(DPHY_REF_CLK_HF), (unsigned int)st);
	return (st == CY_SYSCLK_SUCCESS) ? 0 : -EIO;
}

/* Before the display controller (POST_KERNEL 89) brings up the D-PHY. */
SYS_INIT(dphy_ref_clk_init, POST_KERNEL, 0);

/* Safety net: INT_ST1 is clear-on-read and unused after init, so polling it is safe. */
#define DSI_FIFO_ERR_MSK (GFXSS_MIPIDSI_DWCMIPIDSI_INT_ST1_INT_ST1_DPI_PLD_WR_ERR_Msk | \
			  GFXSS_MIPIDSI_DWCMIPIDSI_INT_ST1_INT_ST1_DPI_BUFF_PLD_UNDER_Msk)

static void dsi_err_poll(struct k_work *work);
static K_WORK_DELAYABLE_DEFINE(dsi_err_work, dsi_err_poll);

/*
 * The DC clock is DPLL_LP0 = IHO 50 MHz x 8, while the D-PHY lane byte clock comes from the
 * 24 MHz EXT crystal. IHO drift makes the DC outrun the DSI link (pixel FIFO overflow and a
 * shifted image), so track IHO against EXT and re-trim the DC fractional divider.
 */
#define IHO_NOMINAL_HZ  50000000ULL
#define DC_PLL_MULT     8ULL
#define DC_PIXEL_HZ     (DT_PROP(DT_NODELABEL(display_controller), pixel_clock_khz) * 1000ULL)
#define MEAS_EXT_COUNT  2400000U /* 100 ms of EXT */
/* IHO swings several hundred ppm within seconds: size for the recent peak plus margin. */
#define DC_SLOW_PPM     1500U
#define PEAK_SAMPLES    10U /* 2 s */
#define TRIM_LOG_EVERY  25U /* samples, 5 s */

static void dc_clk_trim(void)
{
	static bool measuring;
	static uint32_t last_div, samples;
	static uint32_t recent[PEAK_SAMPLES];
	static int32_t ppm_min = INT32_MAX, ppm_max = INT32_MIN;
	uint64_t dc_hz;
	uint32_t iho_hz, iho_peak, div;
	int32_t ppm;

	if (measuring && Cy_SysClk_ClkMeasurementCountersDone()) {
		measuring = false;
		iho_hz = Cy_SysClk_ClkMeasurementCountersGetFreq(true, DPHY_REF_CLK_HZ);
		if (iho_hz > IHO_NOMINAL_HZ * 98U / 100U && iho_hz < IHO_NOMINAL_HZ * 102U / 100U) {
			recent[samples % PEAK_SAMPLES] = iho_hz;
			iho_peak = 0U;
			for (uint32_t i = 0U; i < PEAK_SAMPLES; i++) {
				iho_peak = MAX(iho_peak, recent[i]);
			}
			dc_hz = (uint64_t)iho_peak * DC_PLL_MULT;
			div = (uint32_t)((dc_hz << 16) / DC_PIXEL_HZ);
			div += (uint32_t)((uint64_t)div * DC_SLOW_PPM / 1000000U);
			if (div != last_div) {
				GFXSS->GFXSS_DC.MXDC.CLK_CTL =
					_VAL2FLD(GFXSS_DC_MXDC_CLK_CTL_CLK_DIV, div) |
					GFXSS_DC_MXDC_CLK_CTL_CLK_CORE_Msk;
				last_div = div;
			}

			ppm = (int32_t)(((int64_t)iho_hz - (int64_t)IHO_NOMINAL_HZ) * 1000000 /
					(int64_t)IHO_NOMINAL_HZ);
			ppm_min = MIN(ppm_min, ppm);
			ppm_max = MAX(ppm_max, ppm);
			if (++samples % TRIM_LOG_EVERY == 1U) {
				LOG_INF("IHO %d..%d ppm, DC divider 0x%06x (-%u ppm)", (int)ppm_min,
					(int)ppm_max, (unsigned int)div, DC_SLOW_PPM);
				ppm_min = INT32_MAX;
				ppm_max = INT32_MIN;
			}
		}
	}
	if (!measuring) {
		measuring = Cy_SysClk_StartClkMeasurementCounters(CY_SYSCLK_MEAS_CLK_EXT,
								  MEAS_EXT_COUNT,
								  CY_SYSCLK_MEAS_CLK_IHO) ==
			    CY_SYSCLK_SUCCESS;
	}
}

/* From the ST7703 driver; resets the DSI host into video mode. */
void st7703_dsi_start_video(GFXSS_MIPIDSI_Type *base);

#define DC_ACTIVE_LINES DT_PROP(DT_NODELABEL(display_controller), height)

static uint32_t dc_scan_line(void)
{
	return _FLD2VAL(GFXSS_DC_DCNANO_GCREGDISPLAYCURRENTLOCATION_GCREGDISPLAYCURRENTLOCATION_Y,
			GFXSS->GFXSS_DC.DCNANO.GCREGDISPLAYCURRENTLOCATION);
}

/* Single-buffered UI: start a render just as scan-out leaves the active area so it does not tear. */
void dc_wait_vblank(void)
{
	const uint32_t line_us = 22U; /* 840 clocks at 37.5 MHz */
	uint32_t start = dc_scan_line(), y;
	uint32_t deadline = k_cycle_get_32() + k_us_to_cyc_ceil32(20000U);

	if (start >= DC_ACTIVE_LINES) {
		return;
	}
	if ((DC_ACTIVE_LINES - start) * line_us > 1500U) {
		k_usleep((DC_ACTIVE_LINES - start) * line_us - 1000U);
	}
	do {
		y = dc_scan_line();
	} while (y >= start && y < DC_ACTIVE_LINES && (int32_t)(deadline - k_cycle_get_32()) > 0);
}

/* Start a render just after scan-out passes 'target', giving the GPU the most time before it
 * comes round to rows above it.
 */
void dc_wait_line(uint32_t target)
{
	const uint32_t line_us = 22U;
	const uint32_t total = DC_ACTIVE_LINES + 44U; /* vsync 4 + vfp 20 + vbp 20 */
	uint32_t ahead = (target + total - dc_scan_line()) % total;
	uint32_t deadline = k_cycle_get_32() + k_us_to_cyc_ceil32(20000U);
	uint32_t y;

	if (ahead > total - 30U) {
		return;
	}
	if (ahead * line_us > 1500U) {
		k_usleep(ahead * line_us - 1000U);
	}
	do {
		y = dc_scan_line();
	} while (!(y >= target && y < target + 30U) &&
		 (int32_t)(deadline - k_cycle_get_32()) > 0);
}

/* An offset DSI pixel FIFO only realigns if video restarts between DC frames. */
static bool dsi_resync(void)
{
	uint32_t start = k_cycle_get_32();
	uint32_t timeout = k_us_to_cyc_ceil32(50000U);
	uint32_t prev = dc_scan_line(), y;
	unsigned int key;

	while ((k_cycle_get_32() - start) < timeout) {
		key = irq_lock();
		y = dc_scan_line();
		if (y >= DC_ACTIVE_LINES || y < prev) {
			st7703_dsi_start_video(GFXSS_GFXSS_MIPIDSI);
			irq_unlock(key);
			return true;
		}
		irq_unlock(key);
		prev = y;
	}
	return false;
}

static void dsi_err_poll(struct k_work *work)
{
	static uint32_t overflows, underflows, ticks;
	uint32_t st = GFXSS_GFXSS_MIPIDSI->DWCMIPIDSI.INT_ST1;

	if (++ticks % 10U == 0U) {
		dc_clk_trim();
	}

	if (st & DSI_FIFO_ERR_MSK) {
		overflows += !!(st & GFXSS_MIPIDSI_DWCMIPIDSI_INT_ST1_INT_ST1_DPI_PLD_WR_ERR_Msk);
		underflows += !!(st & GFXSS_MIPIDSI_DWCMIPIDSI_INT_ST1_INT_ST1_DPI_BUFF_PLD_UNDER_Msk);
		LOG_WRN("DSI INT_ST1=0x%08x (pixel FIFO overflow %u, underflow %u), resync %s",
			(unsigned int)st, (unsigned int)overflows, (unsigned int)underflows,
			dsi_resync() ? "ok" : "timed out");
	}
	k_work_reschedule(&dsi_err_work, K_MSEC(20));
}

static int dsi_err_monitor_init(void)
{
	k_work_reschedule(&dsi_err_work, K_MSEC(200));
	return 0;
}
SYS_INIT(dsi_err_monitor_init, APPLICATION, 99);
