/*
 * Copyright (c) 2026 Infineon Technologies AG,
 * or an affiliate of Infineon Technologies AG.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef ZEPHYR_DRIVERS_DISPLAY_DISPLAY_ST7703_H_
#define ZEPHYR_DRIVERS_DISPLAY_DISPLAY_ST7703_H_

#include <zephyr/device.h>

#include "cy_graphics.h"

/* Sends the panel init sequence and leaves the DSI host in command mode.
 * Call after Cy_GFXSS_Init() has brought the DSI host up.
 */
int st7703_dsi_init(const struct device *dev, GFXSS_MIPIDSI_Type *base);

/* Returns the DSI host to video mode. Call right after a DC frame interrupt. */
void st7703_dsi_start_video(GFXSS_MIPIDSI_Type *base);

#endif /* ZEPHYR_DRIVERS_DISPLAY_DISPLAY_ST7703_H_ */
